import subprocess
import sys
import time
import os

def main():
    print("Starting Advanced RAG Application...")
    
    # Start FastAPI backend
    print("Starting FastAPI backend on port 8000...")
    backend_process = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"],
    )
    
    # Give the backend a moment to start
    time.sleep(2)
    
    # Start Streamlit frontend
    print("Starting Streamlit frontend on port 8501...")
    frontend_process = subprocess.Popen(
        [sys.executable, "-m", "streamlit", "run", "frontend/streamlit_app.py", "--server.port", "8501", "--server.address", "0.0.0.0"]
    )
    
    try:
        # Keep the main process alive while the subprocesses are running
        backend_process.wait()
        frontend_process.wait()
    except KeyboardInterrupt:
        print("\nShutting down application...")
        backend_process.terminate()
        frontend_process.terminate()
        backend_process.wait()
        frontend_process.wait()
        print("Shutdown complete.")

if __name__ == "__main__":
    main()
