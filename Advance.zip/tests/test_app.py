"""Unit tests: ZERO real external LLM calls (all LLM boundaries mocked).

- LLMService.safe_rewrite / safe_generate are patched with deterministic,
  call-counted fakes. Real local embeddings + FAISS are used (0 external).
- Tracker budgets asserted: <=1 rewrite, <=1 generation, <=2 total/query.
- One opt-in live integration test (RUN_LIVE_LLM=1) makes real calls;
  skipped by default so the suite never consumes quota accidentally.
"""
import os

os.environ.setdefault("API_TRACKING_ENABLED", "false")

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from app.core.api_tracker import get_totals, reset
from app.main import app

client = TestClient(app)

CALLS = {"rewrite": 0, "generate": 0}


def fake_rewrite(query: str):
    CALLS["rewrite"] += 1
    return query, False  # never rewrite in unit tests (0-effect, counted)


def fake_generate(query: str, chunks):
    CALLS["generate"] += 1
    # Deterministic grounded answer built from evidence (mirrors extractive).
    if not chunks:
        return "I couldn't find enough information in the uploaded documents to answer that.", True
    body = chunks[0].get("text", "")[:400]
    return body + f"\n\nSources: {chunks[0].get('filename', '')}", False


@pytest.fixture(autouse=True)
def mock_llm(request):
    # The opt-in live test must hit the real provider: bypass the mocks there.
    if request.node.name == "test_live_llm_single_question_budget":
        yield
        return
    CALLS["rewrite"] = 0
    CALLS["generate"] = 0
    with (
        patch(
            "app.generation.llm.LLMService.safe_rewrite", side_effect=fake_rewrite
        ),
        patch(
            "app.generation.llm.LLMService.safe_generate", side_effect=fake_generate
        ),
    ):
        yield


@pytest.fixture()
def clean_store():
    from app.retrieval.vectorstore import get_vector_store

    store = get_vector_store()
    store.clear_all()
    reset()
    yield store
    store.clear_all()


def _upload(filename: str, content: bytes, ctype: str):
    return client.post(
        "/api/v1/upload", files={"file": (filename, content, ctype)}
    )


# ---------- API basics (0 LLM) ----------
def test_health_check():
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "message": "API is running."}
    assert CALLS["generate"] == 0


def test_empty_query():
    r = client.post("/api/v1/query", json={"query": ""})
    assert r.status_code == 200
    assert "invalid" in r.json()["answer"].lower()
    assert CALLS["generate"] == 0  # invalid -> END before generation


def test_whitespace_query():
    r = client.post("/api/v1/query", json={"query": "   "})
    assert r.status_code == 200
    assert "invalid" in r.json()["answer"].lower()
    assert CALLS["generate"] == 0


# ---------- ingestion ----------
def test_upload_txt(clean_store):
    r = _upload("doc.txt", b"The project deadline is 15 October 2026.", "text/plain")
    assert r.status_code == 200
    assert r.json()["status"] == "success"
    assert CALLS["generate"] == 0  # ingestion: 0 LLM calls


def test_upload_markdown(clean_store):
    r = _upload("notes.md", b"# Title\n\nSome **markdown** content about vector search.", "text/markdown")
    assert r.status_code == 200
    assert r.json()["document"]["file_type"] == ".md"


def test_upload_pdf(clean_store):
    import pymupdf

    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 72), "The project deadline is 15 October 2026. PDF content here.")
    pdf_bytes = doc.tobytes()
    doc.close()
    r = _upload("doc.pdf", pdf_bytes, "application/pdf")
    assert r.status_code == 200
    assert r.json()["document"]["file_type"] == ".pdf"


def test_unsupported_file(clean_store):
    r = _upload("evil.exe", b"MZ fake", "application/octet-stream")
    assert r.status_code == 400
    assert "unsupported" in r.json()["detail"].lower()


def test_empty_file(clean_store):
    r = _upload("empty.txt", b"", "text/plain")
    assert r.status_code == 400


def test_corrupt_pdf(clean_store):
    r = _upload("bad.pdf", b"%PDF-1.4 not really a pdf %%%", "application/pdf")
    assert r.status_code in (400, 500)


def test_duplicate_upload_returns_409(clean_store):
    body = b"Duplicate content marker 12345."
    r1 = _upload("dup.txt", body, "text/plain")
    assert r1.status_code == 200
    r2 = _upload("dup.txt", body, "text/plain")
    assert r2.status_code == 409


# ---------- chunking ----------
def test_chunking_overlap_and_metadata():
    from app.ingestion.chunker import DocumentChunker

    c = DocumentChunker(chunk_size=100, chunk_overlap=20)
    text = " ".join([f"word{i}" for i in range(80)])
    chunks = c.chunk_documents(
        [{"text": text, "page": None}], document_id="d1", filename="f.txt"
    )
    assert len(chunks) >= 2
    # overlap: some token appears in two consecutive chunks
    toks0 = set(chunks[0]["text"].split())
    toks1 = set(chunks[1]["text"].split())
    assert len(toks0 & toks1) > 0
    for ch in chunks:
        assert ch["document_id"] == "d1"
        assert ch["filename"] == "f.txt"
        assert "chunk_id" in ch and ch["text"]


# ---------- retrieval + grounding (mocked LLM, real local embeddings) ----------
def _seed_two_docs():
    r1 = _upload("alpha.txt", b"The project deadline is 15 October 2026. Alpha only.", "text/plain")
    r2 = _upload("beta.txt", b"Beta document discusses ocean tides and lunar cycles.", "text/plain")
    assert r1.status_code == 200 and r2.status_code == 200
    return r1.json()["document"]["document_id"], r2.json()["document"]["document_id"]


def test_relevant_query_grounded(clean_store):
    _seed_two_docs()
    before = CALLS["generate"]
    r = client.post("/api/v1/query", json={"query": "What is the project deadline?"})
    assert r.status_code == 200
    data = r.json()
    assert "15 October 2026" in data["answer"]
    assert len(data["retrieved_chunks"]) > 0
    assert len(data["sources"]) > 0
    # citations map to real retrieved chunks
    chunk_ids = {c["chunk_id"] for c in data["retrieved_chunks"]}
    assert len(chunk_ids) > 0
    for s in data["sources"]:
        assert s["document_id"]
        assert s["filename"]
    # budget: at most 1 generation for a grounded query
    assert CALLS["generate"] - before <= 1


def test_irrelevant_query_fallback_no_generation(clean_store):
    _seed_two_docs()
    before = CALLS["generate"]
    r = client.post(
        "/api/v1/query", json={"query": "What is the CEO's private phone number?"}
    )
    assert r.status_code == 200
    ans = r.json()["answer"].lower()
    assert "couldn't find" in ans or "could not be found" in ans
    # insufficient evidence -> generation skipped entirely (0 calls)
    assert CALLS["generate"] - before == 0


def test_document_scoped_retrieval(clean_store):
    id_alpha, id_beta = _seed_two_docs()
    r = client.post(
        "/api/v1/query",
        json={"query": "What does this document discuss?", "document_id": id_beta},
    )
    assert r.status_code == 200
    data = r.json()
    assert len(data["retrieved_chunks"]) > 0
    for ch in data["retrieved_chunks"]:
        assert ch["document_id"] == id_beta  # never leaks alpha evidence


def test_unknown_scope_message(clean_store):
    r = client.post(
        "/api/v1/query", json={"query": "What is the deadline?", "document_id": "nope"}
    )
    assert r.status_code == 200
    assert "could not be found" in r.json()["answer"].lower()


# ---------- API + workflow + state ----------
def test_list_and_delete(clean_store):
    r = _upload("todelete.txt", b"Temporary content for deletion.", "text/plain")
    doc_id = r.json()["document"]["document_id"]
    assert any(d["document_id"] == doc_id for d in client.get("/api/v1/documents").json())
    d = client.delete(f"/api/v1/documents/{doc_id}")
    assert d.status_code == 200
    assert all(x["document_id"] != doc_id for x in client.get("/api/v1/documents").json())
    # deleted doc no longer retrievable
    q = client.post("/api/v1/query", json={"query": "Temporary content", "document_id": doc_id})
    assert q.status_code == 200
    assert "could not be found" in q.json()["answer"].lower()


def test_delete_missing_returns_404(clean_store):
    r = client.delete("/api/v1/documents/does-not-exist")
    assert r.status_code == 404


def test_workflow_terminates_linearly(clean_store):
    _seed_two_docs()
    r = client.post("/api/v1/query", json={"query": "What is the project deadline?"})
    steps = r.json()["workflow_steps"]
    assert steps[0] == "validate_query"
    assert steps[-1] == "validate_answer"
    assert len(steps) == len(set(steps))  # no node repeats -> no loops


def test_api_budget_per_query(clean_store):
    _seed_two_docs()
    reset()
    CALLS["rewrite"] = 0
    CALLS["generate"] = 0
    r = client.post("/api/v1/query", json={"query": "What is the project deadline?"})
    assert r.status_code == 200
    api = r.json().get("api_calls", {})
    assert api.get("llm_rewrite", 0) <= 1
    assert api.get("llm_generate", 0) <= 1
    assert api.get("total_external_llm", 0) <= 2
    totals = get_totals()
    assert totals["llm_total"] <= 2


def test_same_question_twice_no_extra_work(clean_store):
    _seed_two_docs()
    q = {"query": "What is the project deadline?"}
    r1 = client.post("/api/v1/query", json=q)
    r2 = client.post("/api/v1/query", json=q)
    assert r1.status_code == 200 and r2.status_code == 200
    assert r1.json()["answer"] == r2.json()["answer"]


def test_upload_alias_route(clean_store):
    with open(__file__, "rb") as f:
        content = f.read(200)
    r = client.post("/api/v1/documents/upload", files={"file": ("x.txt", content, "text/plain")})
    assert r.status_code in (200, 400)


@pytest.mark.skipif(
    os.getenv("RUN_LIVE_LLM") != "1",
    reason="Live LLM test opt-in only (RUN_LIVE_LLM=1) to protect quota.",
)
def test_live_llm_single_question_budget():
    """Self-contained live E2E with the real provider (opt-in: RUN_LIVE_LLM=1).

    Seeds its own fixture document through the real ingestion API, asks ONE
    factual question, and enforces the <=2 external-call budget.
    """
    from app.core.api_tracker import get_totals as gtot
    from app.core.api_tracker import reset as treset
    from app.retrieval.vectorstore import get_vector_store

    store = get_vector_store()
    store.clear_all()
    doc_id = None
    try:
        # 1-5. Ingest a deterministic fixture doc via the real upload API.
        r = _upload(
            "live_deadline.txt",
            b"The project deadline is 15 October 2026.",
            "text/plain",
        )
        assert r.status_code == 200, f"Live setup upload failed: {r.text[:300]}"
        doc_id = r.json()["document"]["document_id"]
        # 6. Confirm it exists in the vector store.
        assert any(
            d["document_id"] == doc_id for d in store.list_documents()
        ), "Fixture document missing from vector store."
        # 7. Reset tracker so ingestion isn't counted as query usage.
        treset()
        # 8-9. ONE factual question against the real provider + real retrieval.
        q = client.post(
            "/api/v1/query", json={"query": "What is the project deadline?"}
        )
        assert q.status_code == 200, f"Live query failed: {q.text[:300]}"
        data = q.json()
        # 10. Grounded non-empty answer communicating the expected fact.
        assert data["answer"] and data["answer"].strip()
        assert "15 October 2026" in data["answer"]
        assert data.get("is_grounded") is True
        # 11. Budget: <=2 external calls, no retries (response + tracker agree).
        assert data.get("api_calls", {}).get("total_external_llm", 99) <= 2
        totals = gtot()
        assert totals["llm_total"] <= 2, f"Budget exceeded: {totals}"
        assert totals["retries"] == 0, f"Unexpected retries: {totals}"
    finally:
        # 13. Clean up so repeated runs start cleanly.
        try:
            if doc_id:
                client.delete(f"/api/v1/documents/{doc_id}")
        finally:
            store.clear_all()