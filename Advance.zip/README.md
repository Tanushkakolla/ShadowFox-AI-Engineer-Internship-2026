# Advanced RAG Assistant (ShadowFox AI Engineer — Advanced Task)

Production-style grounded Q&A over PDF, TXT, and Markdown with FastAPI,
Streamlit, Pydantic, LangGraph, FAISS, local SentenceTransformer embeddings,
and a strict external-API call budget.

## Architecture

```text
Streamlit UI ──► FastAPI ──► LangGraph ──┬──► FAISS (local) + local embeddings
                                         └──► LLM API (1 budgeted call max)
```

LangGraph nodes (linear, no cycles — terminates deterministically):

```text
START → Validate Query → Determine Scope → Rewrite (conditional, ≤1 LLM call)
→ Retrieve (local FAISS, scoped) → Rerank (local) → Grounding Check (local)
→ Generate (≤1 LLM call, skipped if no evidence) → Validate Answer (local) → END
```

Separation: `app/ingestion` (parse/chunk) → `app/retrieval` (embed/index/search)
→ `app/workflow` (orchestration) → `app/generation` (LLM) → `app/api` → `frontend`.

## Tech stack

FastAPI, Streamlit, Pydantic (+ pydantic-settings), LangGraph, FAISS-CPU,
SentenceTransformers (`all-MiniLM-L6-v2`, local, normalized), LangChain
providers (Gemini/OpenAI/Groq), PyMuPDF, Docker.

## Ingestion pipeline

Validate extension/size → read bytes → SHA-256 duplicate check (409 on
duplicate, no re-embedding) → parse → clean → chunk → single batched local
embedding write → FAISS + JSON registry (`document_id, filename, file_type,
chunk_count, content_hash`). Invalid docs (unsupported/empty/corrupt/no-text)
return 400 and never enter the index. Deleting removes index entries +
registry + uploaded file, so stale docs never reappear.

## Chunking strategy

`RecursiveCharacterTextSplitter` (separators `\n\n, \n, space, char`),
defaults **500 chars / 50 overlap** (configurable via `CHUNK_SIZE` /
`CHUNK_OVERLAP`). ~1 paragraph per chunk keeps similarity precise; overlap
preserves split sentences. Every chunk keeps `chunk_id, document_id, filename,
file_type, page (PDF only), chunk_index, text`.

## Embeddings

Local `all-MiniLM-L6-v2`, lazy singleton (never loaded at import; loaded once,
reused; L2-normalized). Ingestion embeds in one batch; queries embed once via
FAISS. **0 external embedding calls.**

## FAISS / vector search

FAISS-CPU `similarity_search_with_score` with over-retrieval then
post-filtering on `document_id`, so scoped queries can never leak cross-doc
evidence. Returns chunk text + `document_id, filename, page, chunk_id,
similarity_score`.

## Document-scoped retrieval

`document_id=null` → all docs; otherwise strictly that doc's chunks. Unknown
IDs return a clean "document not found" message with no evidence claimed. The
UI shows the active scope on every answer.

## Query rewriting

Conditional only: short (≤3 words) or content-word-free queries get at most
**ONE** LLM rewrite; clear factual questions skip rewriting (0 calls).
Failures fall back to the original query (never blocks retrieval).

## Reranking (local, 0 external calls)

Keyword-overlap primary + FAISS distance tiebreak; drops candidates failing
both the distance threshold and zero overlap; keeps top `RERANK_TOP_K`.
Never one-LLM-call-per-chunk.

## Grounding strategy

Local evidence-sufficiency check (best keyword overlap + distance → confidence).
No-evidence → controlled fallback
(`"I couldn't find enough information in the uploaded documents..."`) with
**0 generation calls**. Generation prompt is evidence-only with abstention
instruction. Final local validator flags zero-overlap answers (no second LLM
call). Quota/auth failures → clean 429/503 with retrieved context still shown;
never retried, never fabricated.

## External-API call budget (measured, enforced)

Per normal question: **0–1 rewrite + 0–1 generation = ≤2 external LLM calls**,
0 retries (`max_retries=0`), rerank/grounding/validation/embeddings all local.
Unrelated questions: 0 generation calls (fallback without LLM). Ingestion:
0 external calls. Startup/health: 0. Unit tests: 0 real calls (mocked); one
opt-in live test (`RUN_LIVE_LLM=1`) asserts ≤2.

Development instrumentation (`app/core/api_tracker.py`, disable with
`API_TRACKING_ENABLED=false`) logs `[API CALL #n] type/operation/reason`
(no keys/prompts) and prints a per-query `API CALL SUMMARY`.

## API endpoints

- `GET /api/v1/health` (0 external calls)
- `POST /api/v1/upload` and alias `POST /api/v1/documents/upload` (400 bad file, 409 duplicate)
- `GET /api/v1/documents`
- `DELETE /api/v1/documents/{id}` (404 if missing)
- `POST /api/v1/query` → `QueryResponse(answer, sources, retrieved_chunks, metrics, workflow_steps, rewritten_query, scope, is_grounded, confidence, api_calls)` (429 quota, 503 unavailable)
- `POST /api/v1/query/stream` (SSE: `status` progress events → `result` → `done`; same single-generation budget)

## Streamlit usage

Sidebar: upload → Process (skips duplicates) → doc list with delete → scope
selector (scope shown on every answer). Chat: ask → staged progress →
answer + sources + retrieved chunks + per-answer API-call counts + metrics +
workflow stages. Rerun-safe: cached doc list, submit-guarded queries
(no duplicate sends), explicit delete.

## Environment setup

```bash
python -m venv venv
.\venv\Scripts\activate        # Windows  /  source venv/bin/activate
pip install -r requirements.txt
copy .env.example .env         # then set LLM_PROVIDER + key
python run.py                  # API :8000, UI :8501
```

## Docker setup

```bash
docker compose up --build      # backend :8000, frontend :8501
docker compose config          # validate
```

## Testing

```bash
pytest tests/ -v                                   # mocked, 0 real LLM calls
RUN_LIVE_LLM=1 pytest tests/ -v -k live            # opt-in real-provider check (≤2 calls)
```

Covers: health, empty/whitespace query, PDF/TXT/MD ingest, unsupported/empty/
corrupt/duplicate files, chunk overlap + metadata, relevant vs irrelevant
retrieval, scoped retrieval (no leakage), citations, list/delete + 404,
deleted-doc isolation, linear workflow termination, per-query API budget.

## Design decisions / limitations

- Local embeddings + local rerank/grounding keep quota use at ~1 call/question.
- No token streaming (staged SSE progress instead) to preserve the 1-call budget.
- FAISS + registry persist under `data/`; scale-out would need a shared store.
- `.env` is git-ignored; keys come only from environment. Never logged.
