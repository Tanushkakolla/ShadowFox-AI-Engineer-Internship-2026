"""Streamlit UI. No LLM calls from rendering; one backend call per submit.

Rerun safety:
- Document list is cached (TTL 5s), not refetched in a loop.
- Uploads only fire inside the "Process Documents" button handler.
- Queries only fire inside the chat_input submit handler, guarded by a
  pending flag + duplicate-submit dedupe (same query twice in a row while
  pending does not resend).
- Deletion is per-button with explicit rerun after completion.
"""
import time

import requests
import streamlit as st

API_URL = "http://localhost:8000/api/v1"

st.set_page_config(page_title="Advanced RAG Assistant", page_icon="robot", layout="wide")

if "messages" not in st.session_state:
    st.session_state.messages = []
if "pending" not in st.session_state:
    st.session_state.pending = False
if "last_query" not in st.session_state:
    st.session_state.last_query = ""
if "last_doc_scope" not in st.session_state:
    st.session_state.last_doc_scope = None


@st.cache_data(ttl=5, show_spinner=False)
def fetch_documents_cached(_tick: int):
    try:
        r = requests.get(f"{API_URL}/documents", timeout=10)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return []


def fetch_documents():
    # _tick busts cache at most every 5s; reruns within TTL reuse data.
    return fetch_documents_cached(int(time.time() // 5))


def delete_document(doc_id: str):
    try:
        requests.delete(f"{API_URL}/documents/{doc_id}", timeout=10)
    except Exception:
        pass


st.title("Advanced RAG Assistant")

with st.sidebar:
    st.header("Document Management")
    uploaded_files = st.file_uploader(
        "Upload Documents (PDF, TXT, MD)",
        type=["pdf", "txt", "md"],
        accept_multiple_files=True,
    )

    if st.button("Process Documents", disabled=st.session_state.pending):
        if uploaded_files:
            with st.spinner("Processing (local embeddings, 0 LLM calls)..."):
                for f in uploaded_files:
                    files = {"file": (f.name, f.getvalue(), f.type)}
                    try:
                        res = requests.post(f"{API_URL}/upload", files=files, timeout=120)
                    except Exception as e:
                        st.error(f"Failed to process {f.name}: {e}")
                        continue
                    if res.status_code == 200:
                        st.success(f"Ingested {f.name}")
                    elif res.status_code == 409:
                        st.warning(f"Duplicate skipped: {f.name}")
                    else:
                        try:
                            msg = res.json().get("detail", res.text)
                        except Exception:
                            msg = res.text
                        st.error(f"Failed to process {f.name}: {msg}")
            st.cache_data.clear()
        else:
            st.warning("Please upload a file first.")

    st.divider()
    st.subheader("Indexed Documents")
    docs = fetch_documents()

    if docs:
        for doc in docs:
            col1, col2 = st.columns([3, 1])
            with col1:
                st.caption(f"{doc['filename']} ({doc['chunk_count']} chunks)")
            with col2:
                if st.button("Delete", key=f"del_{doc['document_id']}"):
                    delete_document(doc["document_id"])
                    st.cache_data.clear()
                    st.rerun()
    else:
        st.info("No documents indexed yet.")

    st.divider()
    st.subheader("Query Options")
    doc_options = {"All Documents": None}
    for d in docs:
        doc_options[d["filename"]] = d["document_id"]

    selected_doc_name = st.selectbox("Scope to Document", list(doc_options.keys()))
    selected_doc_id = doc_options[selected_doc_name]
    st.caption(
        f"Retrieval scope: **{selected_doc_name}** — "
        "results come only from the selected document."
        if selected_doc_id
        else "Retrieval scope: **All Documents**."
    )

# Chat history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
        if msg.get("scope"):
            st.caption(f"Scope: {msg['scope']}")
        if msg.get("sources"):
            with st.expander("View Sources"):
                for s in msg["sources"]:
                    st.markdown(f"**{s['filename']}** (Pages: {s['pages']})")
                    st.caption(s["snippet"])
        if msg.get("chunks"):
            with st.expander("Retrieved Chunks"):
                for c in msg["chunks"]:
                    page = f" p.{c.get('page')}" if c.get("page") else ""
                    st.markdown(f"**{c.get('filename', '')}**{page} — chunk {c.get('chunk_id', '')[:8]}")
                    st.caption((c.get("text", "") or "")[:600])
        if msg.get("api_calls"):
            st.caption(
                f"API calls — rewrite: {msg['api_calls'].get('llm_rewrite', 0)}, "
                f"generation: {msg['api_calls'].get('llm_generate', 0)}, "
                f"total: {msg['api_calls'].get('total_external_llm', 0)}"
            )
        if msg.get("metrics"):
            with st.expander("Observability Metrics"):
                st.json(msg["metrics"])
        if msg.get("workflow"):
            with st.expander("Workflow Stages"):
                st.write(" -> ".join(msg["workflow"]))

prompt = st.chat_input(
    "Ask a question about your documents...", disabled=st.session_state.pending
)
if prompt:
    # Dedupe: ignore accidental double-submit of identical query+scope.
    if st.session_state.pending or (
        prompt == st.session_state.last_query
        and selected_doc_id == st.session_state.last_doc_scope
        and any(m.get("content") == prompt for m in st.session_state.messages[-2:])
    ):
        st.warning("Already processing that question — please wait.")
        st.stop()
    st.session_state.pending = True
    st.session_state.last_query = prompt
    st.session_state.last_doc_scope = selected_doc_id
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)

    with st.chat_message("assistant"):
        # Genuine staged progress (mirrors backend nodes); single POST below.
        status = st.status("Working...", expanded=False)
        try:
            status.update(label="Validating query...")
            payload = {"query": prompt, "document_id": selected_doc_id}
            status.update(label="Searching documents + reranking (local)...")
            response = requests.post(f"{API_URL}/query", json=payload, timeout=180)
            status.update(label="Checking grounding + generating answer...")

            if response.status_code == 200:
                data = response.json()
                answer = data["answer"]
                sources = data.get("sources", [])
                chunks = data.get("retrieved_chunks", [])
                metrics = data.get("metrics", {})
                workflow = data.get("workflow_steps", [])
                api_calls = data.get("api_calls", {})
                scope = data.get("scope") or selected_doc_name
                grounded = data.get("is_grounded")

                status.update(label="Done", state="complete")
                st.write(answer)
                st.caption(f"Scope: {scope}")
                if grounded is False:
                    st.warning("Not enough evidence in the selected documents for a grounded answer.")

                if sources:
                    with st.expander("View Sources"):
                        for s in sources:
                            st.markdown(f"**{s['filename']}** (Pages: {s['pages']})")
                            st.caption(s["snippet"])
                if chunks:
                    with st.expander("Retrieved Chunks"):
                        for c in chunks:
                            page = f" p.{c.get('page')}" if c.get("page") else ""
                            st.markdown(f"**{c.get('filename', '')}**{page}")
                            st.caption((c.get("text", "") or "")[:600])
                st.caption(
                    f"API calls — rewrite: {api_calls.get('llm_rewrite', 0)}, "
                    f"generation: {api_calls.get('llm_generate', 0)}, "
                    f"total: {api_calls.get('total_external_llm', 0)}"
                )
                with st.expander("Observability Metrics"):
                    st.json(metrics)
                with st.expander("Workflow Stages"):
                    st.write(" -> ".join(workflow))

                st.session_state.messages.append(
                    {
                        "role": "assistant",
                        "content": answer,
                        "sources": sources,
                        "chunks": chunks,
                        "metrics": metrics,
                        "workflow": workflow,
                        "api_calls": api_calls,
                        "scope": scope,
                    }
                )
            elif response.status_code in (429, 503):
                status.update(label="Service unavailable", state="error")
                try:
                    msg = response.json().get("detail", response.text)
                except Exception:
                    msg = response.text
                st.error(f"Answer service unavailable ({response.status_code}): {msg}")
            else:
                status.update(label="Error", state="error")
                st.error(f"Error: {response.text[:500]}")
        except Exception as e:
            try:
                status.update(label="Error", state="error")
            except Exception:
                pass
            st.error(f"Failed to connect to API: {str(e)[:300]}")
        finally:
            st.session_state.pending = False
