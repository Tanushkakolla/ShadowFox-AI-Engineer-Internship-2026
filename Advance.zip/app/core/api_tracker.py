"""Lightweight development instrumentation for external API calls.

Tracks every external/LLM operation without logging secrets or prompt contents:
  - timestamp, operation type, provider/model, module, reason, seq#, retry flag

Usage:
    from app.core.api_tracker import track, query_scope, get_summary, reset

    with query_scope("What is ...") as ctx:
        track("llm", operation="query_rewrite", reason="vague_query")
        ...
    print(get_summary())

Disable via env: API_TRACKING_ENABLED=false (tracking calls become no-ops,
counters still maintained cheaply for budgets/enforcement).

BUDGETS enforced (per single user query):
  max 1 rewrite, max 1 generation, max 1 rerank-op (local), 0 retries by default.
"""
from __future__ import annotations

import os
import threading
import time
from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

_ENABLED = os.getenv("API_TRACKING_ENABLED", "true").lower() not in {"0", "false", "no"}

_lock = threading.Lock()
_seq = 0
# global totals (process lifetime)
_totals: Dict[str, int] = {
    "llm_rewrite": 0,
    "llm_generate": 0,
    "llm_total": 0,
    "embedding_local": 0,
    "retrieval_local": 0,
    "rerank_local": 0,
    "grounding_local": 0,
    "retries": 0,
}
# per-query context (thread-local-ish via contextvar would be ideal; use simple stack)
_local = threading.local()


def _next_seq() -> int:
    global _seq
    with _lock:
        _seq += 1
        return _seq


def _current_ctx() -> Optional[Dict[str, Any]]:
    return getattr(_local, "ctx", None)


@contextmanager
def query_scope(query_id: str = "") -> Generator[Dict[str, Any], None, None]:
    """Per-query tracking scope. Yields mutable counter dict."""
    ctx: Dict[str, Any] = {
        "query_id": query_id[:80],
        "started": time.time(),
        "llm_rewrite": 0,
        "llm_generate": 0,
        "retries": 0,
        "skipped_rewrite": False,
        "skipped_generation": False,
    }
    prev = getattr(_local, "ctx", None)
    _local.ctx = ctx
    try:
        yield ctx
    finally:
        _local.ctx = prev


def track(
    call_type: str,
    operation: str,
    reason: str = "",
    provider: str = "",
    model: str = "",
    module: str = "",
    is_retry: bool = False,
) -> int:
    """Record one external call. Returns global sequence number."""
    n = _next_seq()
    with _lock:
        if call_type == "llm" and operation == "query_rewrite":
            _totals["llm_rewrite"] += 1
            _totals["llm_total"] += 1
        elif call_type == "llm" and operation == "answer_generation":
            _totals["llm_generate"] += 1
            _totals["llm_total"] += 1
        elif call_type == "embedding_local":
            _totals["embedding_local"] += 1
        elif call_type == "retrieval_local":
            _totals["retrieval_local"] += 1
        elif call_type == "rerank_local":
            _totals["rerank_local"] += 1
        elif call_type == "grounding_local":
            _totals["grounding_local"] += 1
        if is_retry:
            _totals["retries"] += 1
    ctx = _current_ctx()
    if ctx is not None:
        with _lock:
            if call_type == "llm" and operation == "query_rewrite":
                ctx["llm_rewrite"] = ctx.get("llm_rewrite", 0) + 1
            elif call_type == "llm" and operation == "answer_generation":
                ctx["llm_generate"] = ctx.get("llm_generate", 0) + 1
            if is_retry:
                ctx["retries"] = ctx.get("retries", 0) + 1
    if _ENABLED:
        ts = time.strftime("%H:%M:%S")
        retry_flag = " retry=1" if is_retry else ""
        # Never log prompt contents or keys.
        print(
            f"[API CALL #{n}] {ts} type={call_type} operation={operation} "
            f"provider={provider or '-'} model={model or '-'} "
            f"module={module or '-'} reason={reason or '-'}"
            f"{retry_flag}",
            flush=True,
        )
    # Budget guardrails: hard-fail loudly in dev if exceeded (prevents silent loops).
    if ctx is not None:
        if ctx.get("llm_rewrite", 0) > 1:
            print(f"[BUDGET VIOLATION] >1 rewrite in one query (n={n})", flush=True)
        if ctx.get("llm_generate", 0) > 1:
            print(f"[BUDGET VIOLATION] >1 generation in one query (n={n})", flush=True)
    return n


def note_skip(operation: str, reason: str = "") -> None:
    ctx = _current_ctx()
    if ctx is not None:
        if operation == "query_rewrite":
            ctx["skipped_rewrite"] = True
        if operation == "answer_generation":
            ctx["skipped_generation"] = True
    if _ENABLED:
        print(f"[API SKIP] operation={operation} reason={reason}", flush=True)


def get_summary() -> str:
    with _lock:
        t = dict(_totals)
    ctx = _current_ctx()
    lines = [
        "API CALL SUMMARY",
        "----------------",
        f"Embedding calls (local, external=0): {t['embedding_local']}",
        f"Query rewrite LLM calls: {t['llm_rewrite']}",
        f"Reranking calls (local, external=0): {t['rerank_local']}",
        f"Grounding calls (local, external=0): {t['grounding_local']}",
        f"Generation LLM calls: {t['llm_generate']}",
        f"Retries: {t['retries']}",
        f"TOTAL EXTERNAL LLM CALLS: {t['llm_total']}",
    ]
    if ctx is not None:
        lines += [
            "--- this query ---",
            f"rewrite: {ctx.get('llm_rewrite', 0)} "
            f"(skipped={ctx.get('skipped_rewrite', False)})",
            f"generation: {ctx.get('llm_generate', 0)} "
            f"(skipped={ctx.get('skipped_generation', False)})",
            f"retries: {ctx.get('retries', 0)}",
            f"TOTAL EXTERNAL THIS QUERY: "
            f"{ctx.get('llm_rewrite', 0) + ctx.get('llm_generate', 0)}",
        ]
    return "\n".join(lines)


def get_totals() -> Dict[str, int]:
    with _lock:
        return dict(_totals)


def reset() -> None:
    global _seq
    with _lock:
        _seq = 0
        for k in _totals:
            _totals[k] = 0
