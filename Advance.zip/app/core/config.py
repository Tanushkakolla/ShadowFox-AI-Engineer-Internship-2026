import os
from pydantic_settings import BaseSettings, SettingsConfigDict

SUPPORTED_EXTENSIONS = {".pdf", ".txt", ".md"}
FALLBACK_ANSWER = "I couldn't find enough information in the uploaded documents to answer that."
INVALID_QUERY_ANSWER = "Invalid or empty query. Please ask a clear question about your documents."


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    PROJECT_NAME: str = "Advanced RAG Application"
    API_V1_STR: str = "/api/v1"

    # Chunking Configuration
    CHUNK_SIZE: int = 500
    CHUNK_OVERLAP: int = 50

    # Embedding Configuration
    EMBEDDING_MODEL: str = "all-MiniLM-L6-v2"

    # Retrieval Configuration
    TOP_K: int = 5
    RERANK_TOP_K: int = 3
    # FAISS with normalized embeddings uses L2 distance in [0, ~2].
    # Chunks with distance above this are treated as weak candidates.
    SIMILARITY_THRESHOLD: float = 1.2
    # Minimum keyword overlap (content words) for a chunk to count as grounding.
    MIN_KEYWORD_OVERLAP: int = 1

    # LLM Configuration
    # Supports "gemini", "openai", "groq", "fake"
    LLM_PROVIDER: str = "groq"
    LLM_MODEL: str = "llama3-8b-8192"
    OPENAI_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    GROQ_API_KEY: str = ""

    # File Storage
    UPLOAD_DIR: str = "data/uploads"
    VECTOR_DB_DIR: str = "data/vectorstore"
    MAX_FILE_SIZE_MB: int = 15


settings = Settings()

# Ensure directories exist (cheap, no model loading here)
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(settings.VECTOR_DB_DIR, exist_ok=True)
