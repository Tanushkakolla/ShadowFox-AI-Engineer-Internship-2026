from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional


class HealthResponse(BaseModel):
    status: str
    message: str


class DocumentMetadata(BaseModel):
    document_id: str
    filename: str
    file_type: str
    chunk_count: int


class DocumentUploadResponse(BaseModel):
    status: str  # success | duplicate
    message: str
    document: DocumentMetadata


class DocumentDeleteResponse(BaseModel):
    status: str
    message: str


class ErrorResponse(BaseModel):
    status: str = "error"
    message: str
    detail: Optional[str] = None


class QueryRequest(BaseModel):
    query: str = Field(..., description="The user's question.")
    document_id: Optional[str] = Field(
        None, description="Scope query to a specific document ID."
    )


class RetrievedChunk(BaseModel):
    chunk_id: str
    text: str
    document_id: str
    filename: str
    page: Optional[int] = None
    similarity_score: float


class SourceCitation(BaseModel):
    document_id: str
    filename: str
    pages: List[int]
    snippet: str


class ApiCallSummary(BaseModel):
    llm_rewrite: int = 0
    llm_generate: int = 0
    total_external_llm: int = 0
    retries: int = 0
    skipped_rewrite: bool = False
    skipped_generation: bool = False


class QueryResponse(BaseModel):
    answer: str
    sources: List[SourceCitation]
    retrieved_chunks: List[RetrievedChunk]
    metrics: Dict[str, Any]
    workflow_steps: List[str]
    # Observability (new, optional for backward compat)
    rewritten_query: Optional[str] = None
    scope: Optional[str] = None
    is_grounded: Optional[bool] = None
    confidence: Optional[float] = None
    api_calls: Optional[ApiCallSummary] = None
