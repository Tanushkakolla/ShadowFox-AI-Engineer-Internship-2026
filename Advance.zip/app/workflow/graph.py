"""LangGraph agentic RAG workflow.

Nodes (each with a real responsibility):
  validate_query  -> reject empty/whitespace/too-short queries
  determine_scope -> resolve document scope (all vs one doc), validate doc exists
  rewrite_query   -> conditionally refine vague queries via LLM (skip clear ones)
  retrieve        -> FAISS scoped retrieval (over-retrieve for rerank)
  rerank          -> lightweight deterministic rerank: vector score + keyword overlap
  grounding_check -> decide if evidence suffices; else controlled fallback
  generate        -> grounded generation (real LLM, extractive fallback offline)
  validate_answer -> enforce non-empty, evidence-tied answers; map citations

START -> validate -> scope -> rewrite -> retrieve -> rerank -> grounding
      -> generate -> validate -> END
"""
from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, StateGraph

from app.core.config import FALLBACK_ANSWER, INVALID_QUERY_ANSWER, settings


class AgentState(TypedDict, total=False):
    original_query: str
    document_id: Optional[str]
    query: str
    rewritten_query: Optional[str]
    was_rewritten: bool
    scope_label: str
    scope_valid: bool
    retrieved_chunks: List[Dict[str, Any]]
    reranked_chunks: List[Dict[str, Any]]
    answer: str
    is_valid_query: bool
    is_grounded: bool
    used_fallback_generation: bool
    confidence: float
    metrics: Dict[str, Any]
    workflow_steps: List[str]


_STOPWORDS = {
    "what", "is", "the", "a", "an", "of", "in", "on", "for", "to", "and",
    "or", "does", "do", "did", "how", "why", "when", "where", "which",
    "who", "whom", "whose", "with", "about", "tell", "me", "please",
    "you", "your", "it", "its", "this", "that", "these", "those", "are",
    "was", "were", "be", "been", "by", "as", "at", "from", "into", "more",
    "give", "show", "list", "find", "explain", "describe", "summarize",
}


def _content_tokens(text: str) -> set:
    toks = set(re.findall(r"[a-z0-9]+", (text or "").lower()))
    return {t for t in toks if t not in _STOPWORDS and len(t) > 2}


def _keyword_overlap(query: str, chunk_text: str) -> int:
    return len(_content_tokens(query) & _content_tokens(chunk_text))


def _needs_rewrite(query: str) -> bool:
    """Only vague/short queries benefit from rewriting."""
    words = query.strip().split()
    if len(words) <= 3:
        return True
    lowered = query.lower().strip()
    vague = {
        "it", "this", "that", "more", "details", "explain", "why?",
        "how?", "what?", "tell me more", "explain this", "more info",
    }
    if lowered in vague:
        return True
    # no content words -> vague
    if not _content_tokens(query):
        return True
    return False


class RAGWorkflow:
    def __init__(self, vector_store=None):
        # Lazy imports keep module import cheap (no model loading).
        if vector_store is None:
            from app.retrieval.vectorstore import get_vector_store

            vector_store = get_vector_store()
        self.vector_store = vector_store
        self.workflow = self._create_workflow()

    # ---------- nodes ----------
    def validate_query(self, state: AgentState) -> AgentState:
        query = (state.get("original_query") or "").strip()
        # collapse internal whitespace
        query = re.sub(r"\s+", " ", query)
        is_valid = len(query) >= 3
        state["is_valid_query"] = is_valid
        state["query"] = query
        state["workflow_steps"].append("validate_query")
        return state

    def determine_scope(self, state: AgentState) -> AgentState:
        doc_id = state.get("document_id")
        if not doc_id:
            state["scope_label"] = "all_documents"
            state["scope_valid"] = True
        else:
            try:
                doc = self.vector_store.get_document(doc_id)
            except Exception:
                doc = None
            if doc:
                state["scope_label"] = doc.get("filename", doc_id)
                state["scope_valid"] = True
            else:
                state["scope_label"] = f"unknown:{doc_id}"
                state["scope_valid"] = False
        state["workflow_steps"].append("determine_scope")
        return state

    def rewrite_query(self, state: AgentState) -> AgentState:
        from app.core.api_tracker import note_skip

        start = time.time()
        original = state.get("query", "")
        if _needs_rewrite(original):
            # Max ONE rewrite attempt; safe_rewrite never retries.
            from app.generation.llm import LLMService

            rewritten, changed = LLMService.safe_rewrite(original)
            state["query"] = rewritten
            state["rewritten_query"] = rewritten
            state["was_rewritten"] = changed
        else:
            # Clear query: skip LLM entirely (0 calls).
            note_skip("query_rewrite", reason="query_already_clear")
            state["rewritten_query"] = original
            state["was_rewritten"] = False
        state["metrics"]["rewrite_latency"] = time.time() - start
        state["metrics"]["was_rewritten"] = state["was_rewritten"]
        state["workflow_steps"].append("rewrite_query")
        return state

    def retrieve(self, state: AgentState) -> AgentState:
        from app.core.api_tracker import track

        start = time.time()
        track(
            "retrieval_local", operation="faiss_search", reason="scoped_retrieval",
            module="app.workflow.graph.retrieve",
        )
        if not state.get("scope_valid", True):
            state["retrieved_chunks"] = []
        else:
            try:
                initial_k = max(settings.TOP_K * 2, settings.TOP_K + 3)
                chunks = self.vector_store.search(
                    query=state.get("query", ""),
                    top_k=initial_k,
                    document_id=state.get("document_id"),
                )
            except Exception as e:
                chunks = []
                state["metrics"]["retrieve_error"] = str(e)[:300]
            state["retrieved_chunks"] = chunks
        state["metrics"]["retrieve_latency"] = time.time() - start
        state["metrics"]["retrieved_count"] = len(state["retrieved_chunks"])
        state["workflow_steps"].append("retrieve")
        return state

    def rerank(self, state: AgentState) -> AgentState:
        """Deterministic LOCAL rerank (0 external calls).

        1. Score each candidate: overlap (content-word matches with query).
        2. Drop candidates failing BOTH: distance > threshold AND zero overlap.
        3. Sort by (-overlap, distance) and keep top RERANK_TOP_K.
        """
        from app.core.api_tracker import track

        start = time.time()
        track(
            "rerank_local", operation="rerank", reason="local_deterministic",
            module="app.workflow.graph.rerank",
        )
        query = state.get("query", "")
        chunks = state.get("retrieved_chunks", []) or []
        threshold = float(settings.SIMILARITY_THRESHOLD)
        scored = []
        for c in chunks:
            overlap = _keyword_overlap(query, c.get("text", ""))
            dist = float(c.get("similarity_score", 99.0))
            c = dict(c)
            c["keyword_overlap"] = overlap
            scored.append((overlap, dist, c))
        # filter: keep if close enough OR has keyword evidence
        kept = [t for t in scored if t[1] <= threshold or t[0] > 0]
        kept.sort(key=lambda t: (-t[0], t[1]))
        top_k = int(settings.RERANK_TOP_K or settings.TOP_K)
        reranked = [dict(t[2]) for t in kept[:top_k]]
        # re-rank scores for display: 1-based rank
        for i, c in enumerate(reranked):
            c["rerank"] = i + 1
        state["reranked_chunks"] = reranked
        state["metrics"]["rerank_latency"] = time.time() - start
        state["metrics"]["reranked_count"] = len(reranked)
        state["workflow_steps"].append("rerank")
        return state

    def grounding_check(self, state: AgentState) -> AgentState:
        from app.core.api_tracker import track

        start = time.time()
        track(
            "grounding_local", operation="grounding_check",
            reason="local_evidence_sufficiency",
            module="app.workflow.graph.grounding_check",
        )
        reranked = state.get("reranked_chunks", []) or []
        if not reranked:
            grounded = False
            confidence = 0.0
        else:
            best_overlap = max(int(c.get("keyword_overlap", 0)) for c in reranked)
            best_dist = min(float(c.get("similarity_score", 99.0)) for c in reranked)
            required = int(settings.MIN_KEYWORD_OVERLAP)
            if best_overlap >= max(required, 1):
                grounded = True
            elif best_dist <= float(settings.SIMILARITY_THRESHOLD) / 2 and best_overlap >= 1:
                grounded = True
            else:
                # Single-chunk edge: if the top chunk is very close vector-wise,
                # accept it even with weak lexical overlap.
                grounded = best_dist <= 0.35
            # confidence: blend of overlap and distance
            overlap_part = min(best_overlap / 5.0, 1.0)
            dist_part = max(0.0, 1.0 - (best_dist / 2.0))
            confidence = round(0.6 * overlap_part + 0.4 * dist_part, 3)
            if not grounded:
                confidence = min(confidence, 0.35)
        state["is_grounded"] = grounded
        state["confidence"] = confidence if reranked else 0.0
        state["metrics"]["grounding_latency"] = time.time() - start
        state["metrics"]["is_grounded"] = grounded
        state["metrics"]["confidence"] = state["confidence"]
        state["workflow_steps"].append("grounding_check")
        return state

    def generate(self, state: AgentState) -> AgentState:
        from app.core.api_tracker import note_skip

        start = time.time()
        if not state.get("is_grounded"):
            # No evidence: controlled fallback, ZERO external calls.
            state["answer"] = FALLBACK_ANSWER
            state["used_fallback_generation"] = False
            note_skip("answer_generation", reason="insufficient_evidence")
            state["workflow_steps"].append("generate_fallback")
        else:
            from app.generation.llm import (
                LLMQuotaError,
                LLMService,
                LLMUnavailableError,
                extractive_answer,
            )

            try:
                answer, used_fallback = LLMService.safe_generate(
                    state.get("query", ""), state.get("reranked_chunks", [])
                )
                state["answer"] = answer
                state["used_fallback_generation"] = used_fallback
                state["workflow_steps"].append(
                    "generate_extractive" if used_fallback else "generate"
                )
            except LLMQuotaError as e:
                # Quota exhausted: clean error, NO retry, NO fabricated answer.
                state["answer"] = (
                    "The answer service is temporarily unavailable due to API quota limits. "
                    "Your documents are indexed and relevant context was found — "
                    "please try again later."
                )
                state["metrics"]["llm_error"] = f"quota:{str(e)[:200]}"
                state["is_grounded"] = True  # evidence exists; generation blocked
                state["used_fallback_generation"] = False
                state["workflow_steps"].append("generate_quota_error")
            except LLMUnavailableError as e:
                state["answer"] = (
                    "The answer service is temporarily unavailable "
                    f"({str(e)[:150]}). Relevant context was retrieved and is shown below."
                )
                state["metrics"]["llm_error"] = f"unavailable:{str(e)[:200]}"
                state["used_fallback_generation"] = False
                state["workflow_steps"].append("generate_unavailable")
        state["metrics"]["generate_latency"] = time.time() - start
        return state

    def validate_answer(self, state: AgentState) -> AgentState:
        """Final LOCAL guard (0 external calls): never return empty answers.

        Does NOT call the LLM again. If the generated answer is empty, use the
        controlled fallback. If it shares zero content tokens with evidence and
        is not an explicit abstention/error message, keep it but flag low
        confidence (do not fabricate a replacement via another LLM call).
        """
        start = time.time()
        answer = (state.get("answer") or "").strip()
        reranked = state.get("reranked_chunks", []) or []
        if not answer:
            state["answer"] = FALLBACK_ANSWER
            state["is_grounded"] = False
        elif state.get("is_grounded") and reranked:
            ans_toks = _content_tokens(answer)
            ev_toks: set = set()
            for c in reranked:
                ev_toks |= _content_tokens(c.get("text", ""))
            low = answer.lower()
            abstained = (
                "couldn't find" in low
                or "could not be found" in low
                or "temporarily unavailable" in low
                or "quota" in low
            )
            if ans_toks and not (ans_toks & ev_toks) and not abstained:
                # Local hallucination flag: lower confidence, keep answer but
                # record the issue. No second LLM call.
                state["metrics"]["hallucination_flag"] = True
                state["confidence"] = min(float(state.get("confidence", 0.5)), 0.3)
        state["metrics"]["validate_latency"] = time.time() - start
        state["workflow_steps"].append("validate_answer")
        return state

    # ---------- routing ----------
    def should_continue(self, state: AgentState):
        if not state.get("is_valid_query"):
            return "end"
        return "continue"

    def _create_workflow(self):
        workflow = StateGraph(AgentState)
        workflow.add_node("validate_query", self.validate_query)
        workflow.add_node("determine_scope", self.determine_scope)
        workflow.add_node("rewrite_query", self.rewrite_query)
        workflow.add_node("retrieve", self.retrieve)
        workflow.add_node("rerank", self.rerank)
        workflow.add_node("grounding_check", self.grounding_check)
        workflow.add_node("generate", self.generate)
        workflow.add_node("validate_answer", self.validate_answer)
        workflow.set_entry_point("validate_query")
        workflow.add_conditional_edges(
            "validate_query", self.should_continue, {"continue": "determine_scope", "end": END}
        )
        workflow.add_edge("determine_scope", "rewrite_query")
        workflow.add_edge("rewrite_query", "retrieve")
        workflow.add_edge("retrieve", "rerank")
        workflow.add_edge("rerank", "grounding_check")
        workflow.add_edge("grounding_check", "generate")
        workflow.add_edge("generate", "validate_answer")
        workflow.add_edge("validate_answer", END)
        return workflow.compile()

    def run(self, query: str, document_id: Optional[str] = None) -> Dict[str, Any]:
        from app.core.api_tracker import get_summary, query_scope

        initial_state: AgentState = {
            "original_query": query or "",
            "document_id": document_id,
            "query": "",
            "rewritten_query": None,
            "was_rewritten": False,
            "scope_label": "all_documents",
            "scope_valid": True,
            "retrieved_chunks": [],
            "reranked_chunks": [],
            "answer": "",
            "is_valid_query": False,
            "is_grounded": False,
            "used_fallback_generation": False,
            "confidence": 0.0,
            "metrics": {},
            "workflow_steps": [],
        }
        start = time.time()
        try:
            with query_scope(query or ""):
                final_state = self.workflow.invoke(initial_state)
                # Development log: exact per-query external-call count.
                try:
                    print(get_summary(), flush=True)
                except Exception:
                    pass
        except Exception as e:
            # Absolute last resort: never crash the API.
            return {
                "original_query": query,
                "document_id": document_id,
                "query": (query or "").strip(),
                "rewritten_query": (query or "").strip(),
                "was_rewritten": False,
                "scope_label": "all_documents",
                "scope_valid": True,
                "retrieved_chunks": [],
                "reranked_chunks": [],
                "answer": FALLBACK_ANSWER,
                "is_valid_query": bool((query or "").strip()),
                "is_grounded": False,
                "used_fallback_generation": True,
                "confidence": 0.0,
                "metrics": {"total_latency": time.time() - start, "workflow_error": str(e)[:300]},
                "workflow_steps": ["validate_query", "error_fallback"],
            }
        final_state["metrics"]["total_latency"] = time.time() - start
        if not final_state.get("is_valid_query"):
            final_state["answer"] = INVALID_QUERY_ANSWER
        if not final_state.get("scope_valid"):
            # Invalid scope -> no evidence should be claimed.
            final_state["answer"] = (
                "The selected document could not be found. "
                "It may have been deleted. Please choose another document or search all documents."
            )
            final_state["is_grounded"] = False
            final_state["reranked_chunks"] = []
            final_state["retrieved_chunks"] = []
        return final_state
