"""FastAPI routes. No external calls at import time.

- Vector store / chunker / workflow are lazy singletons (no model loading on
  import or on /health).
- Upload: validates type/size/emptiness BEFORE indexing; SHA-256 duplicate
  detection returns 409 for exact duplicates (no re-embedding).
- Query: exactly one LangGraph run per request; quota errors -> 429,
  provider errors -> 503, no retries, no loops. Per-query API summary included.
- Aliases: both /upload and /documents/upload per the task spec.
- POST /query/stream is SSE with genuine staged progress events + final
  payload. Still exactly ONE generation call (no faked token streaming).
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import time
import uuid
from typing import List, Optional

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse

from app.core.api_tracker import get_totals
from app.core.config import SUPPORTED_EXTENSIONS, settings
from app.ingestion.chunker import DocumentChunker
from app.ingestion.parser import DocumentParser
from app.models.schemas import (
    ApiCallSummary,
    DocumentDeleteResponse,
    DocumentMetadata,
    DocumentUploadResponse,
    HealthResponse,
    QueryRequest,
    QueryResponse,
    RetrievedChunk,
    SourceCitation,
)

router = APIRouter()

# Lazy singletons: nothing heavy happens at import.
_vector_store = None
_chunker = None
_workflow = None


def get_store():
    global _vector_store
    if _vector_store is None:
        from app.retrieval.vectorstore import get_vector_store

        _vector_store = get_vector_store()
    return _vector_store


def get_chunker() -> DocumentChunker:
    global _chunker
    if _chunker is None:
        _chunker = DocumentChunker(
            chunk_size=settings.CHUNK_SIZE, chunk_overlap=settings.CHUNK_OVERLAP
        )
    return _chunker


def get_workflow():
    global _workflow
    if _workflow is None:
        from app.workflow.graph import RAGWorkflow

        _workflow = RAGWorkflow(vector_store=get_store())
    return _workflow


@router.get("/health", response_model=HealthResponse)
async def health_check():
    # 0 external calls by design.
    return HealthResponse(status="ok", message="API is running.")


def _validate_upload(filename: str, size_bytes: int) -> str:
    ext = os.path.splitext(filename or "")[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format: '{ext}'. Supported: PDF, TXT, Markdown.",
        )
    max_bytes = int(settings.MAX_FILE_SIZE_MB) * 1024 * 1024
    if size_bytes > max_bytes:
        raise HTTPException(
            status_code=400,
            detail=f"File too large ({size_bytes / 1048576:.1f} MB). Max is {settings.MAX_FILE_SIZE_MB} MB.",
        )
    return ext


async def _ingest_upload(file: UploadFile):
    store = get_store()
    chunker = get_chunker()
    start = time.time()
    file_id = str(uuid.uuid4())
    orig_name = file.filename or "upload.bin"
    ext = _validate_upload(orig_name, 0)  # extension pre-check (size checked after read)

    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="File is empty (0 bytes).")
    max_bytes = int(settings.MAX_FILE_SIZE_MB) * 1024 * 1024
    if len(raw) > max_bytes:
        raise HTTPException(
            status_code=400,
            detail=f"File too large ({len(raw) / 1048576:.1f} MB). Max is {settings.MAX_FILE_SIZE_MB} MB.",
        )

    content_hash = DocumentParser.compute_hash_bytes(raw)
    dup = store.find_by_hash(content_hash)
    if dup:
        raise HTTPException(
            status_code=409,
            detail=f"Duplicate document (already indexed as {dup.get('filename')}).",
        )

    safe_path = os.path.join(settings.UPLOAD_DIR, f"{file_id}{ext}")
    try:
        with open(safe_path, "wb") as out:
            out.write(raw)
        parsed = DocumentParser.parse_file(safe_path, orig_name)
        chunks = chunker.chunk_documents(parsed, document_id=file_id, filename=orig_name)
        # Single batched local-embedding write (0 external calls).
        store.add_chunks(chunks)
        store.register_document(
            file_id,
            {
                "filename": orig_name,
                "file_type": ext,
                "chunk_count": len(chunks),
                "content_hash": content_hash,
                "upload_time": time.time(),
            },
        )
    except HTTPException:
        try:
            if os.path.exists(safe_path):
                os.remove(safe_path)
        except OSError:
            pass
        raise
    except ValueError as e:
        try:
            if os.path.exists(safe_path):
                os.remove(safe_path)
        except OSError:
            pass
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        try:
            if os.path.exists(safe_path):
                os.remove(safe_path)
        except OSError:
            pass
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {str(e)[:300]}")

    took = time.time() - start
    return DocumentUploadResponse(
        status="success",
        message=f"Successfully ingested {orig_name} in {took:.2f}s",
        document=DocumentMetadata(
            document_id=file_id, filename=orig_name, file_type=ext,
            chunk_count=len(chunks),
        ),
    )


@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(file: UploadFile = File(...)):
    return await _ingest_upload(file)


# Spec alias: POST /documents/upload
@router.post("/documents/upload", response_model=DocumentUploadResponse)
async def upload_document_alias(file: UploadFile = File(...)):
    return await _ingest_upload(file)


@router.get("/documents", response_model=List[DocumentMetadata])
async def list_documents():
    return get_store().list_documents()


@router.delete("/documents/{document_id}", response_model=DocumentDeleteResponse)
async def delete_document(document_id: str):
    store = get_store()
    try:
        found = store.delete_document(document_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Delete failed: {str(e)[:300]}")
    # Clean uploaded file(s) for this document.
    try:
        for name in os.listdir(settings.UPLOAD_DIR):
            if name.startswith(document_id):
                try:
                    os.remove(os.path.join(settings.UPLOAD_DIR, name))
                except OSError:
                    pass
    except OSError:
        pass
    if not found:
        raise HTTPException(status_code=404, detail=f"Document {document_id} not found.")
    return DocumentDeleteResponse(status="success", message=f"Document {document_id} deleted.")


def _state_to_response(state: dict) -> QueryResponse:
    sources = []
    retrieved = []
    source_map: dict = {}
    for chunk in state.get("reranked_chunks", []) or []:
        doc_id = chunk.get("document_id", "")
        if doc_id not in source_map:
            source_map[doc_id] = {
                "document_id": doc_id,
                "filename": chunk.get("filename", ""),
                "pages": set(),
                "snippets": [],
            }
        if chunk.get("page"):
            try:
                source_map[doc_id]["pages"].add(int(chunk["page"]))
            except (TypeError, ValueError):
                pass
        source_map[doc_id]["snippets"].append((chunk.get("text", "") or "")[:200] + "...")
        retrieved.append(
            RetrievedChunk(
                chunk_id=chunk.get("chunk_id", ""),
                text=chunk.get("text", ""),
                document_id=doc_id,
                filename=chunk.get("filename", ""),
                page=chunk.get("page"),
                similarity_score=float(chunk.get("similarity_score", 0.0)),
            )
        )
    for doc_id, data in source_map.items():
        sources.append(
            SourceCitation(
                document_id=doc_id,
                filename=data["filename"],
                pages=sorted(data["pages"]),
                snippet="\n".join(data["snippets"]),
            )
        )
    metrics = dict(state.get("metrics", {}))
    # Attach process-lifetime external-call totals for observability.
    totals = get_totals()
    metrics.setdefault("api_llm_total", totals.get("llm_total", 0))
    steps = state.get("workflow_steps", []) or []
    n_rewrite = 1 if state.get("was_rewritten") else 0
    n_generate = 1 if "generate" in steps else 0
    api = ApiCallSummary(
        llm_rewrite=n_rewrite,
        llm_generate=n_generate,
        total_external_llm=n_rewrite + n_generate,
        retries=0,
        skipped_rewrite=not bool(state.get("was_rewritten")),
        skipped_generation="generate" not in steps,
    )
    return QueryResponse(
        answer=state.get("answer", ""),
        sources=sources,
        retrieved_chunks=retrieved,
        metrics=metrics,
        workflow_steps=state.get("workflow_steps", []),
        rewritten_query=state.get("rewritten_query"),
        scope=state.get("scope_label"),
        is_grounded=state.get("is_grounded"),
        confidence=state.get("confidence"),
        api_calls=api,
    )


@router.post("/query", response_model=QueryResponse)
async def query_assistant(request: QueryRequest):
    # Exactly ONE workflow run per request (no loops, no retries).
    workflow = get_workflow()
    try:
        state = workflow.run(query=request.query, document_id=request.document_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)[:300]}")
    metrics = state.get("metrics", {})
    if isinstance(metrics.get("llm_error"), str):
        if metrics["llm_error"].startswith("quota:"):
            raise HTTPException(status_code=429, detail=state.get("answer", "Quota exceeded."))
        raise HTTPException(status_code=503, detail=state.get("answer", "LLM unavailable."))
    return _state_to_response(state)


@router.post("/query/stream")
async def query_stream(request: QueryRequest):
    """SSE with genuine staged progress + single final result.

    Events: status (validate/scope/rewrite/retrieve/rerank/grounding/generate),
    then result (full QueryResponse JSON), then done. Exactly ONE generation
    call happens server-side; the stream reflects real node progress, not
    faked tokens.
    """
    workflow = get_workflow()

    async def event_gen():
        stages = [
            "validating_query", "resolving_scope", "refining_query",
            "searching_documents", "reranking_evidence",
            "checking_grounding", "generating_answer",
        ]
        for s in stages:
            yield f"event: status\ndata: {json.dumps({'stage': s})}\n\n"
            await asyncio.sleep(0)  # yield control; real work happens below
        try:
            # Run blocking workflow in a thread (single run, no retry).
            state = await asyncio.to_thread(
                workflow.run, request.query, request.document_id
            )
        except Exception as e:
            yield f"event: error\ndata: {json.dumps({'message': str(e)[:300]})}\n\n"
            return
        metrics = state.get("metrics", {})
        if isinstance(metrics.get("llm_error"), str):
            code = 429 if metrics["llm_error"].startswith("quota:") else 503
            yield f"event: error\ndata: {json.dumps({'code': code, 'message': state.get('answer', '')[:500]})}\n\n"
            return
        resp = _state_to_response(state)
        yield f"event: result\ndata: {resp.model_dump_json()}\n\n"
        yield "event: done\ndata: {}\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream")
