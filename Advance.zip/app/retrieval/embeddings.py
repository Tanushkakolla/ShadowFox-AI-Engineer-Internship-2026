"""Lazy-loaded sentence-transformer embeddings.

The heavy model is never loaded at import time. Call get_instance()
explicitly; the singleton is cached and reused for all queries.
Embeddings are L2-normalized so FAISS inner-product / L2 scores are
comparable (cosine-like behavior).
"""
from __future__ import annotations

from typing import List

from app.core.config import settings


class EmbeddingService:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            try:
                from langchain_huggingface import HuggingFaceEmbeddings
            except ImportError:  # fallback for older installs
                from langchain_community.embeddings import HuggingFaceEmbeddings  # type: ignore
            # Lazy initialization of the embedding model (cached thereafter).
            cls._instance = HuggingFaceEmbeddings(
                model_name=settings.EMBEDDING_MODEL,
                model_kwargs={"device": "cpu"},
                encode_kwargs={"normalize_embeddings": True},
            )
        return cls._instance

    @classmethod
    def embed_documents(cls, texts: List[str]) -> List[List[float]]:
        # Local embeddings: 0 external API calls. Batched in ONE model call.
        from app.core.api_tracker import track

        try:
            model = cls.get_instance()
            track(
                "embedding_local", operation="embed_documents",
                reason=f"batch_ingest_n={len(texts)}",
                module="app.retrieval.embeddings",
            )
            return model.embed_documents(texts)
        except Exception as e:
            raise RuntimeError(f"Embedding generation failed: {e}")

    @classmethod
    def embed_query(cls, text: str) -> List[float]:
        from app.core.api_tracker import track

        try:
            model = cls.get_instance()
            track(
                "embedding_local", operation="embed_query", reason="user_query",
                module="app.retrieval.embeddings",
            )
            return model.embed_query(text)
        except Exception as e:
            raise RuntimeError(f"Embedding generation failed: {e}")
