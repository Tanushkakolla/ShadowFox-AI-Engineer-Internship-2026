"""FAISS vector store with provenance-preserving chunks.

Design notes:
- Heavy embedding model is loaded lazily (never at import).
- A singleton instance is shared app-wide via get_vector_store().
- Every chunk keeps: chunk_id, document_id, filename, file_type, page,
  chunk_index, text, plus similarity_score at query time.
- Document-scoped retrieval is enforced by post-filtering on document_id
  (robust across FAISS versions) so a scoped query can never leak
  evidence from another document.
- A tiny JSON registry tracks document metadata + content hashes for
  duplicate detection and listing without scanning the index.
"""
from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Dict, List, Optional

from langchain_core.documents import Document

from app.core.config import settings

_REGISTRY_FILENAME = "documents_registry.json"


class VectorStore:
    def __init__(self):
        self.index_name = "rag_index"
        self.vector_dir = settings.VECTOR_DB_DIR
        os.makedirs(self.vector_dir, exist_ok=True)
        self._embeddings = None
        self._db = None
        self._lock = threading.Lock()
        self._registry_path = os.path.join(self.vector_dir, _REGISTRY_FILENAME)

    # ---- lazy internals ----
    @property
    def embeddings(self):
        if self._embeddings is None:
            from app.retrieval.embeddings import EmbeddingService

            self._embeddings = EmbeddingService.get_instance()
        return self._embeddings

    @property
    def db(self):
        if self._db is None:
            self._db = self._load_or_create_db()
        return self._db

    def _registry_load(self) -> Dict[str, Any]:
        try:
            if os.path.exists(self._registry_path):
                with open(self._registry_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _registry_save(self, data: Dict[str, Any]) -> None:
        try:
            with open(self._registry_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def _load_or_create_db(self):
        from langchain_community.vectorstores import FAISS

        index_path = os.path.join(self.vector_dir, f"{self.index_name}.faiss")
        if os.path.exists(index_path):
            try:
                return FAISS.load_local(
                    folder_path=self.vector_dir,
                    embeddings=self.embeddings,
                    index_name=self.index_name,
                    allow_dangerous_deserialization=True,
                )
            except Exception:
                pass
        # Empty store: dummy doc so FAISS has a valid index structure.
        dummy = Document(page_content="__init__", metadata={"dummy": True})
        try:
            return FAISS.from_documents([dummy], self.embeddings)
        except Exception as e:
            raise RuntimeError(f"Vector index initialization failed: {e}")

    def _is_dummy_only(self) -> bool:
        try:
            if self._db is None:
                # check on disk
                index_path = os.path.join(self.vector_dir, f"{self.index_name}.faiss")
                return not os.path.exists(index_path)
            if self._db.index.ntotal <= 1:
                keys = list(self._db.docstore._dict.keys())
                if not keys:
                    return True
                first = self._db.docstore._dict.get(keys[0])
                if first is not None and first.metadata.get("dummy"):
                    return self._db.index.ntotal == 1
                return False
            return False
        except Exception:
            return False

    # ---- writes ----
    def add_chunks(self, chunks: List[Dict[str, Any]]) -> None:
        if not chunks:
            return
        from app.core.api_tracker import track

        from langchain_community.vectorstores import FAISS

        # Local embedding batch: 0 external calls. One FAISS write per upload
        # (no per-chunk API calls, no re-embedding on query/rerun).
        track(
            "embedding_local", operation="embed_documents",
            reason=f"ingest_batch_n={len(chunks)}",
            module="app.retrieval.vectorstore.add_chunks",
        )

        documents = []
        for chunk in chunks:
            metadata = {
                "chunk_id": chunk.get("chunk_id"),
                "document_id": chunk.get("document_id"),
                "filename": chunk.get("filename"),
                "file_type": chunk.get("file_type"),
                "page": chunk.get("page"),
                "chunk_index": chunk.get("chunk_index", 0),
            }
            metadata = {k: v for k, v in metadata.items() if v is not None}
            documents.append(Document(page_content=chunk["text"], metadata=metadata))

        with self._lock:
            try:
                if self._is_dummy_only():
                    self._db = FAISS.from_documents(documents, self.embeddings)
                else:
                    self.db.add_documents(documents)
                self.save()
            except Exception as e:
                raise RuntimeError(f"Vector index write failed: {e}")

    def register_document(self, document_id: str, meta: Dict[str, Any]) -> None:
        reg = self._registry_load()
        reg[document_id] = meta
        self._registry_save(reg)

    def find_by_hash(self, content_hash: str) -> Optional[Dict[str, Any]]:
        reg = self._registry_load()
        for doc_id, meta in reg.items():
            if meta.get("content_hash") == content_hash:
                return {"document_id": doc_id, **meta}
        return None

    def get_document(self, document_id: str) -> Optional[Dict[str, Any]]:
        reg = self._registry_load()
        if document_id in reg:
            return {"document_id": document_id, **reg[document_id]}
        # fallback: scan index
        for doc in self.list_documents():
            if doc.get("document_id") == document_id:
                return doc
        return None

    def delete_document(self, document_id: str) -> bool:
        with self._lock:
            ids_to_delete = []
            try:
                for key, doc in list(self.db.docstore._dict.items()):
                    if doc.metadata.get("document_id") == document_id:
                        ids_to_delete.append(key)
            except Exception as e:
                raise RuntimeError(f"Vector index read failed: {e}")
            if not ids_to_delete:
                # still clean registry; report not-found
                reg = self._registry_load()
                reg.pop(document_id, None)
                self._registry_save(reg)
                return False
            try:
                self.db.delete(ids_to_delete)
                self.save()
            except Exception as e:
                raise RuntimeError(f"Vector index delete failed: {e}")
            reg = self._registry_load()
            reg.pop(document_id, None)
            self._registry_save(reg)
            return True

    def clear_all(self) -> None:
        """Test helper: wipe index + registry."""
        with self._lock:
            from langchain_community.vectorstores import FAISS

            dummy = Document(page_content="__init__", metadata={"dummy": True})
            try:
                self._db = FAISS.from_documents([dummy], self.embeddings)
                self.save()
            except Exception:
                self._db = None
            self._registry_save({})

    # ---- reads ----
    def search(
        self, query: str, top_k: int = 5, document_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        if not query or not query.strip():
            return []
        try:
            _ = self.db
        except Exception as e:
            raise RuntimeError(f"Vector index unavailable: {e}")
        if self._is_dummy_only():
            return []
        # Over-retrieve then post-filter by document_id. This is deliberate:
        # it guarantees scoped retrieval even if the underlying FAISS
        # filter semantics differ across versions.
        fetch_k = max(top_k * 4, top_k + 5)
        try:
            docs_and_scores = self.db.similarity_search_with_score(query, k=fetch_k)
        except Exception as e:
            raise RuntimeError(f"Vector search failed: {e}")

        results: List[Dict[str, Any]] = []
        for doc, score in docs_and_scores:
            if doc.metadata.get("dummy"):
                continue
            doc_id = doc.metadata.get("document_id", "")
            if document_id and doc_id != document_id:
                continue
            results.append(
                {
                    "chunk_id": doc.metadata.get("chunk_id", ""),
                    "text": doc.page_content,
                    "document_id": doc_id,
                    "filename": doc.metadata.get("filename", ""),
                    "file_type": doc.metadata.get("file_type"),
                    "page": doc.metadata.get("page"),
                    "chunk_index": doc.metadata.get("chunk_index", 0),
                    "similarity_score": float(score),
                }
            )
            if len(results) >= top_k:
                break
        return results

    def save(self):
        try:
            self.db.save_local(folder_path=self.vector_dir, index_name=self.index_name)
        except Exception as e:
            raise RuntimeError(f"Vector index save failed: {e}")

    def list_documents(self) -> List[Dict[str, Any]]:
        reg = self._registry_load()
        if reg:
            out = []
            for doc_id, meta in reg.items():
                out.append(
                    {
                        "document_id": doc_id,
                        "filename": meta.get("filename", "Unknown"),
                        "file_type": meta.get("file_type", "Unknown"),
                        "chunk_count": int(meta.get("chunk_count", 0)),
                    }
                )
            # include any indexed docs missing from registry (legacy data)
            try:
                if not self._is_dummy_only():
                    seen = set(reg.keys())
                    counts: Dict[str, Dict[str, Any]] = {}
                    for doc in self.db.docstore._dict.values():
                        d = doc.metadata.get("document_id")
                        if not d or d in seen or doc.metadata.get("dummy"):
                            continue
                        if d not in counts:
                            counts[d] = {
                                "document_id": d,
                                "filename": doc.metadata.get("filename", "Unknown"),
                                "file_type": doc.metadata.get("file_type")
                                or os.path.splitext(doc.metadata.get("filename", ""))[1]
                                or "Unknown",
                                "chunk_count": 0,
                            }
                        counts[d]["chunk_count"] += 1
                    out.extend(counts.values())
            except Exception:
                pass
            return out
        # no registry: scan index
        try:
            if self._is_dummy_only():
                return []
        except Exception:
            return []
        docs_map: Dict[str, Dict[str, Any]] = {}
        try:
            for doc in self.db.docstore._dict.values():
                if doc.metadata.get("dummy"):
                    continue
                doc_id = doc.metadata.get("document_id")
                if not doc_id:
                    continue
                if doc_id not in docs_map:
                    docs_map[doc_id] = {
                        "document_id": doc_id,
                        "filename": doc.metadata.get("filename", "Unknown"),
                        "file_type": doc.metadata.get("file_type")
                        or os.path.splitext(doc.metadata.get("filename", ""))[1]
                        or "Unknown",
                        "chunk_count": 0,
                    }
                docs_map[doc_id]["chunk_count"] += 1
        except Exception:
            return []
        return list(docs_map.values())


# Module-level lazy singleton. Importing this module must NOT load models.
_singleton: Optional[VectorStore] = None
_singleton_lock = threading.Lock()


def get_vector_store() -> VectorStore:
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = VectorStore()
    return _singleton
