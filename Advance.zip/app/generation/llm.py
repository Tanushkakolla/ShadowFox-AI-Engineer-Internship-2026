"""LLM access with strict call budgets and no silent loops.

Call budget per user query:
  - max 1 query-rewrite LLM call (only for vague queries; clear queries skip)
  - max 1 answer-generation LLM call (skipped when evidence is insufficient)
  - max_retries = 0 for LLM construction (no automatic retry multiplication)
  - reranking + grounding are LOCAL (0 external calls)

On quota/rate-limit/auth failures the error is propagated as LLMQuotaError /
LLMUnavailableError so the API can return a clean 429/503 WITHOUT retrying
or fabricating an answer. The deterministic extractive_answer() helper is used
ONLY for provider=fake (unit tests) and never as a silent stand-in for the
real model in production.
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Tuple

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage
import langchain_core.outputs

from app.core.config import settings

# Retry policy: LangChain chat models retry internally by default.
# We pin max_retries=1 (single attempt + at most one retry is avoided;
# we use 0 to guarantee ONE HTTP attempt per logical call).
LLM_MAX_RETRIES = 0


class LLMQuotaError(RuntimeError):
    """Quota / rate-limit exhausted. Caller must return 429, no retry."""


class LLMUnavailableError(RuntimeError):
    """Auth/network/model failure. Caller must return 503, no retry."""


class FakeLLM(BaseChatModel):
    """Deterministic stub used ONLY when LLM_PROVIDER=fake (unit tests)."""

    @property
    def _llm_type(self) -> str:
        return "fake-llm"

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        try:
            query = str(messages[-1].content)[:500]
        except Exception:
            query = "test"
        return langchain_core.outputs.ChatResult(
            generations=[
                langchain_core.outputs.ChatGeneration(
                    message=AIMessage(content=f"Fake response for: {query}")
                )
            ]
        )


def _is_quota_error_text(text: str) -> bool:
    t = (text or "").lower()
    markers = [
        "429", "quota", "rate limit", "rate_limit", "rate-limit",
        "resource_exhausted", "too many requests", "exceed",
        "insufficient_quota", "billing",
    ]
    return any(m in t for m in markers)


def _is_auth_error_text(text: str) -> bool:
    t = (text or "").lower()
    markers = [
        "401", "403", "api key not valid", "api_key_invalid",
        "invalid api key", "unauthorized", "permission_denied",
        "invalid_argument", "api key",
    ]
    return any(m in t for m in markers)


class LLMService:
    _instance = None

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    @classmethod
    def provider_name(cls) -> str:
        return (settings.LLM_PROVIDER or "groq").lower()

    @classmethod
    def get_instance(cls) -> BaseChatModel:
        if cls._instance is None:
            provider = cls.provider_name()
            if provider == "gemini":
                if settings.GEMINI_API_KEY:
                    os.environ["GOOGLE_API_KEY"] = settings.GEMINI_API_KEY
                from langchain_google_genai import ChatGoogleGenerativeAI

                cls._instance = ChatGoogleGenerativeAI(
                    model=settings.LLM_MODEL,
                    temperature=0.0,
                    max_retries=LLM_MAX_RETRIES,
                )
            elif provider == "openai":
                if settings.OPENAI_API_KEY:
                    os.environ["OPENAI_API_KEY"] = settings.OPENAI_API_KEY
                from langchain_openai import ChatOpenAI

                cls._instance = ChatOpenAI(
                    model_name=settings.LLM_MODEL,
                    temperature=0.0,
                    max_retries=LLM_MAX_RETRIES,
                )
            elif provider == "groq":
                if settings.GROQ_API_KEY:
                    os.environ["GROQ_API_KEY"] = settings.GROQ_API_KEY
                from langchain_groq import ChatGroq

                cls._instance = ChatGroq(
                    model_name=settings.LLM_MODEL,
                    temperature=0.0,
                    max_retries=LLM_MAX_RETRIES,
                )
            elif provider == "fake":
                cls._instance = FakeLLM()
            else:
                raise ValueError(f"Unsupported LLM provider: {settings.LLM_PROVIDER}")
        return cls._instance

    # ---- budgeted wrappers (max 1 call each, 0 retries) ----
    @classmethod
    def safe_rewrite(cls, query: str) -> Tuple[str, bool]:
        """At most ONE rewrite attempt. Returns (query, was_rewritten).

        Never raises. On any LLM failure returns the original query.
        Rewrite failures must never block retrieval.
        """
        from app.core.api_tracker import note_skip, track

        try:
            llm = cls.get_instance()
            if isinstance(llm, FakeLLM):
                note_skip("query_rewrite", reason="fake_provider_no_external_call")
                return query, False
        except Exception:
            note_skip("query_rewrite", reason="llm_unavailable")
            return query, False
        try:
            from langchain_core.output_parsers import StrOutputParser
            from langchain_core.prompts import ChatPromptTemplate

            track(
                "llm", operation="query_rewrite", reason="vague_query",
                provider=cls.provider_name(), model=settings.LLM_MODEL,
                module="app.generation.llm.safe_rewrite",
            )
            prompt = ChatPromptTemplate.from_messages(
                [
                    (
                        "system",
                        "You optimize user queries for vector database retrieval. "
                        "If the query is already clear, output it exactly as is. "
                        "If vague, rewrite it to be more descriptive. "
                        "Output ONLY the rewritten query.",
                    ),
                    ("human", "{query}"),
                ]
            )
            chain = prompt | llm | StrOutputParser()
            # Single attempt; LangChain retries disabled via max_retries=0.
            rewritten = chain.invoke({"query": query})
            rewritten = (rewritten or "").strip().strip('"').strip("'")
            if not rewritten:
                return query, False
            return rewritten, (rewritten != query)
        except Exception as e:
            # Rewrite is best-effort: never retry, never block.
            note_skip("query_rewrite", reason=f"rewrite_failed:{type(e).__name__}")
            return query, False

    @classmethod
    def safe_generate(
        cls, query: str, context_chunks: List[Dict[str, Any]]
    ) -> Tuple[str, bool]:
        """Exactly ONE generation attempt. Returns (answer, used_fallback).

        Raises LLMQuotaError / LLMUnavailableError on real-provider failure
        (caller converts to clean 429/503 with no retry). For provider=fake,
        returns a deterministic extractive answer with 0 external calls.
        """
        from app.core.api_tracker import note_skip, track

        provider = cls.provider_name()
        if provider == "fake":
            note_skip("answer_generation", reason="fake_provider_local_extractive")
            return extractive_answer(query, context_chunks), True

        llm = cls.get_instance()  # may raise -> caller handles
        if isinstance(llm, FakeLLM):  # defensive
            return extractive_answer(query, context_chunks), True

        context_str = build_context_string(context_chunks)
        track(
            "llm", operation="answer_generation", reason="grounded_answer",
            provider=provider, model=settings.LLM_MODEL,
            module="app.generation.llm.safe_generate",
        )
        try:
            from langchain_core.output_parsers import StrOutputParser
            from langchain_core.prompts import ChatPromptTemplate

            prompt = ChatPromptTemplate.from_messages(
                [
                    (
                        "system",
                        "You are a document-grounded assistant.\n"
                        "Only use the supplied retrieved context to answer.\n"
                        "If the answer is not supported by the context, say you "
                        "couldn't find enough information in the uploaded documents.\n"
                        "Do not invent citations or facts. Cite file and page when possible.",
                    ),
                    ("human", "RETRIEVED CONTEXT:\n{context}\n\nQUESTION:\n{query}"),
                ]
            )
            chain = prompt | llm | StrOutputParser()
            answer = chain.invoke({"context": context_str, "query": query})
            answer = (answer or "").strip()
            if not answer:
                raise LLMUnavailableError("Empty model response.")
            return answer, False
        except LLMQuotaError:
            raise
        except LLMUnavailableError:
            raise
        except Exception as e:
            msg = f"{type(e).__name__}: {e}"
            if _is_quota_error_text(msg):
                raise LLMQuotaError(
                    "LLM quota/rate limit exceeded. Please try again later."
                ) from e
            if _is_auth_error_text(msg):
                raise LLMUnavailableError(
                    "LLM provider authentication failed. Check server API key configuration."
                ) from e
            raise LLMUnavailableError(f"LLM request failed: {type(e).__name__}.") from e


def build_context_string(chunks: List[Dict[str, Any]]) -> str:
    parts = []
    for c in chunks:
        meta = f"File: {c.get('filename', 'unknown')}"
        if c.get("page"):
            meta += f", Page: {c.get('page')}"
        parts.append(f"--- Context from {meta} ---\n{c.get('text', '')}")
    return "\n\n".join(parts)


def extractive_answer(query: str, chunks: List[Dict[str, Any]]) -> str:
    """Deterministic grounded answer for provider=fake (tests) only."""
    if not chunks:
        from app.core.config import FALLBACK_ANSWER

        return FALLBACK_ANSWER
    query_terms = set(re.findall(r"[a-z0-9]+", query.lower()))
    stop = {
        "what", "is", "the", "a", "an", "of", "in", "on", "for", "to", "and",
        "or", "does", "do", "did", "how", "why", "when", "where", "which",
        "who", "whom", "whose", "with", "about", "tell", "me", "please",
        "you", "your", "it", "its", "this", "that", "these", "those",
    }
    content_terms = {t for t in query_terms if t not in stop and len(t) > 2}

    best: List[str] = []
    for c in chunks[:3]:
        text = c.get("text", "")
        sentences = re.split(r"(?<=[.!?])\s+", text.strip())
        if not sentences:
            continue
        scored = []
        for s in sentences:
            s_terms = set(re.findall(r"[a-z0-9]+", s.lower()))
            overlap = len(content_terms & s_terms) if content_terms else 0
            scored.append((overlap, -len(s), s))
        scored.sort(reverse=True)
        top = scored[0][2] if scored else text[:300]
        best.append(top.strip())

    seen: set = set()
    unique: List[str] = []
    for s in best:
        if s and s not in seen:
            seen.add(s)
            unique.append(s)
    body = " ".join(unique[:3]).strip() or chunks[0].get("text", "")[:500]

    cites = []
    for c in chunks[:3]:
        name = c.get("filename", "document")
        cites.append(f"{name} (p. {c.get('page')})" if c.get("page") else f"{name}")
    return f"{body}\n\nSources: " + "; ".join(cites)
