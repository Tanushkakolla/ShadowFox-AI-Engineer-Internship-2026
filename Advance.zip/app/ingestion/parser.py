import hashlib
import os
import re
import pymupdf  # PyMuPDF
from typing import List, Dict, Any, Optional

from app.core.config import SUPPORTED_EXTENSIONS


class DocumentParser:
    SUPPORTED = SUPPORTED_EXTENSIONS

    @staticmethod
    def validate_extension(filename: str) -> str:
        ext = os.path.splitext(filename)[1].lower()
        if ext not in DocumentParser.SUPPORTED:
            raise ValueError(
                f"Unsupported file format: '{ext}'. Supported: PDF, TXT, Markdown."
            )
        return ext

    @staticmethod
    def compute_hash_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def compute_file_hash(file_path: str) -> str:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            for block in iter(lambda: f.read(65536), b""):
                h.update(block)
        return h.hexdigest()

    @staticmethod
    def clean_text(text: str) -> str:
        # Normalize whitespace, strip control chars, collapse blank lines.
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = re.sub(r"[ \t]{2,}", " ", text)
        return text.strip()

    @staticmethod
    def parse_file(file_path: str, filename: str) -> List[Dict[str, Any]]:
        """
        Parses a file and returns a list of dictionaries with text and metadata.
        For PDFs, it returns a dict per page.
        For TXT and MD, it returns a single dict for the whole file.
        Raises ValueError for unsupported/corrupt/empty documents.
        """
        ext = DocumentParser.validate_extension(filename)
        if ext == ".pdf":
            return DocumentParser._parse_pdf(file_path)
        return DocumentParser._parse_text(file_path)

    @staticmethod
    def _parse_pdf(file_path: str) -> List[Dict[str, Any]]:
        if os.path.getsize(file_path) == 0:
            raise ValueError("File is empty (0 bytes).")
        docs = []
        try:
            doc = pymupdf.open(file_path)
        except Exception as e:
            raise ValueError(f"Failed to parse PDF (corrupt or invalid PDF): {str(e)}")
        try:
            if len(doc) == 0:
                raise ValueError("PDF has no pages.")
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                raw = page.get_text("text") or ""
                text = DocumentParser.clean_text(raw)
                if text:
                    docs.append({"text": text, "page": page_num + 1})
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to parse PDF: {str(e)}")
        finally:
            try:
                doc.close()
            except Exception:
                pass

        if not docs:
            raise ValueError("No extractable text found in PDF.")
        return docs

    @staticmethod
    def _parse_text(file_path: str) -> List[Dict[str, Any]]:
        if os.path.getsize(file_path) == 0:
            raise ValueError("File is empty (0 bytes).")
        try:
            with open(file_path, "r", encoding="utf-8", errors="strict") as f:
                raw = f.read()
        except UnicodeDecodeError:
            raise ValueError("Failed to parse text file: not valid UTF-8 text.")
        except Exception as e:
            raise ValueError(f"Failed to parse text file: {str(e)}")
        text = DocumentParser.clean_text(raw)
        if not text:
            raise ValueError("File is empty or contains no extractable text.")
        return [{"text": text, "page": None}]
