from typing import List, Dict, Any
from langchain_text_splitters import RecursiveCharacterTextSplitter
import os
import uuid


class DocumentChunker:
    """Recursive character chunking with configurable size/overlap.

    Strategy: RecursiveCharacterTextSplitter on ["\\n\\n", "\\n", " ", ""].
    Defaults 500 chars / 50 overlap (~a paragraph) keep retrieval precise
    while overlap preserves sentences split across boundaries.
    """

    def __init__(self, chunk_size: int = 500, chunk_overlap: int = 50):
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        if chunk_overlap < 0 or chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be >= 0 and < chunk_size")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=["\n\n", "\n", " ", ""],
        )

    def chunk_documents(
        self, parsed_docs: List[Dict[str, Any]], document_id: str, filename: str
    ) -> List[Dict[str, Any]]:
        file_type = os.path.splitext(filename)[1].lower()
        chunks = []
        global_index = 0
        for doc in parsed_docs:
            text = (doc.get("text") or "").strip()
            if not text:
                continue
            page = doc.get("page")

            split_texts = self.splitter.split_text(text)

            for i, chunk_text in enumerate(split_texts):
                chunk_text = chunk_text.strip()
                if not chunk_text:
                    continue
                chunks.append(
                    {
                        "chunk_id": str(uuid.uuid4()),
                        "text": chunk_text,
                        "document_id": document_id,
                        "filename": filename,
                        "file_type": file_type,
                        "page": page,
                        "chunk_index": global_index,
                    }
                )
                global_index += 1

        if not chunks:
            raise ValueError("Document produced no chunks (no extractable text).")
        return chunks
