import os
from groq import Groq, APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = "openai/gpt-oss-120b"
DEFAULT_TEMPERATURE = 0.7
DEFAULT_MAX_TOKENS = 1024


def _get_client():
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise ValueError("GROQ_API_KEY not found. Set it in your .env file.")
    return Groq(api_key=api_key)


def call_groq(messages, model=None, temperature=None, max_tokens=None):
    model = model or os.environ.get("GROQ_MODEL", DEFAULT_MODEL)
    temperature = temperature if temperature is not None else DEFAULT_TEMPERATURE
    max_tokens = max_tokens or DEFAULT_MAX_TOKENS

    try:
        client = _get_client()
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content

    except AuthenticationError:
        raise RuntimeError("Invalid API key. Please check your GROQ_API_KEY.")
    except RateLimitError:
        raise RuntimeError("Rate limit reached. Please wait a moment and try again.")
    except APIConnectionError:
        raise RuntimeError("Unable to connect to Groq API. Check your internet connection.")
    except APIStatusError as e:
        raise RuntimeError(f"API error occurred (status {e.status_code}). Please try again.")
    except ValueError:
        raise
    except Exception as e:
        raise RuntimeError("An unexpected error occurred. Please try again.")
