# StudyMate AI

An AI-powered student utility application that helps students study more effectively using structured LLM interactions.

## Problem Statement

Students often struggle with:
- Summarizing lengthy lecture notes before exams
- Self-testing their understanding of material
- Getting clear explanations of difficult concepts
- Improving weak answers in assignments

Manual study processes are time-consuming and sometimes ineffective. Students need a tool that leverages AI to assist with these specific study tasks in a structured, purposeful way.

## Solution

StudyMate AI provides four focused study utilities, each powered by the Groq API with carefully designed prompts. The application is not a generic chatbot — each feature has a specific purpose, input requirements, and tailored output format designed for student workflows.

## Features

### 1. Summarize Notes
- **Input:** Paste lecture notes or study material
- **Output:** A concise bullet-point summary capturing main ideas, key terms, and essential points
- **Use case:** Quickly review material before an exam

### 2. Generate Quiz
- **Input:** Paste study notes and select question count (3-10)
- **Output:** A quiz with multiple choice, true/false, and short answer questions, plus an answer key
- **Use case:** Self-test understanding of study material

### 3. Explain Concept
- **Input:** Enter a concept or topic name
- **Output:** A structured explanation with definition, detailed breakdown, example, and importance
- **Use case:** Understand a difficult topic from your coursework

### 4. Improve Answer
- **Input:** Enter the question and your current answer
- **Output:** An improved version that preserves your intent while adding clarity and completeness
- **Use case:** Strengthen assignment responses before submission

## Technology Stack

| Component | Technology |
|---|---|
| Language | Python 3.12 |
| UI Framework | Streamlit |
| LLM Provider | Groq API |
| LLM Model | llama-3.3-70b-versatile (configurable) |
| Environment Management | python-dotenv |
| Version Control | Git |

## Application Workflow

```
User selects a study tool from the sidebar
    |
    v
User enters content in the labeled input fields
    |
    v
Input validation checks for empty/invalid input
    |
    v (if valid)
Feature-specific structured prompt is constructed
    |
    v
Prompt is sent to the Groq API
    |
    v
Response is received and formatted
    |
    v
Output is displayed in readable markdown format
```

## Architecture

The application follows a clean separation of concerns:

| File | Responsibility |
|---|---|
| `app.py` | Streamlit UI, user interaction flow, input validation, output display |
| `prompts.py` | Structured prompt templates for all four features |
| `utils.py` | Groq API integration, client setup, error handling |

### Data Flow

1. `app.py` captures user input and validates it
2. `app.py` calls the appropriate prompt builder from `prompts.py`
3. `prompts.py` returns a structured messages array (system + user roles)
4. `app.py` passes the messages to `call_groq()` in `utils.py`
5. `utils.py` sends the request to the Groq API and returns the response
6. `app.py` displays the formatted output to the user

## Prompt Design Approach

Each feature uses a dedicated prompt template designed for its specific purpose. Prompts are not generic — they are structured with:

- **Role:** Defines the AI's persona (e.g., "You are a study assistant that summarizes academic notes")
- **Task:** Clear instruction on what to produce
- **Output format:** Specific formatting requirements (bullet points, numbered lists, sections)
- **Constraints:** Quality guidelines (word limits, accuracy requirements, tone)

### Example: Summarize Notes Prompt

```
System: "You are a study assistant that summarizes academic notes.
Given a set of notes, produce a clear and concise summary that captures
the main ideas, key terms, and essential points.
Use bullet points for clarity.
Keep the summary under 300 words.
Do not add information that is not present in the original notes."

User: "Summarize the following notes:\n\n{student's notes}"
```

### Example: Generate Quiz Prompt

```
System: "You are a study assistant that creates quizzes from study notes.
Given a set of notes, generate a quiz with the specified number of questions.
Use a mix of question types: multiple choice, true/false, and short answer.
For multiple choice, provide 4 options labeled A through D.
After all questions, provide an answer key."

User: "Create a quiz with {n} questions from the following notes:\n\n{notes}"
```

This approach ensures outputs are relevant, properly formatted, and aligned with the intended study task.

## Input Validation

All input is validated before making an API request:

| Validation | Applied To | Behavior |
|---|---|---|
| Empty input | All features | Warning message, no API call |
| Whitespace-only input | All features | Warning message, no API call |
| Insufficient length | Summarize Notes (< 50 chars), Generate Quiz (< 30 chars) | Warning message, no API call |
| Missing fields | Improve Answer (both question and answer required) | Warning message, no API call |

Validation failures never trigger API requests, preventing unnecessary network calls and costs.

## API Error Handling

The application handles these API failure scenarios:

| Error Type | User Message |
|---|---|
| Missing API key | "GROQ_API_KEY not found. Set it in your .env file." |
| Invalid API key | "Invalid API key. Please check your GROQ_API_KEY." |
| Rate limiting | "Rate limit reached. Please wait a moment and try again." |
| Network failure | "Unable to connect to Groq API. Check your internet connection." |
| API server error | "API error occurred (status XXX). Please try again." |
| Unexpected error | "An unexpected error occurred. Please try again." |

The application never crashes on API errors. Users see clear, actionable messages and can retry their request.

## Security and API Key Handling

- The Groq API key is stored in a `.env` file (not committed to version control)
- `.gitignore` excludes `.env` and other sensitive files
- `.env.example` provides a template with placeholder values
- API keys are never hardcoded, printed, logged, or displayed in the UI
- Error messages never expose internal details or secrets

### Setup

1. Clone the repository
2. Create a `.env` file from the template:
   ```
   cp .env.example .env
   ```
3. Add your Groq API key to `.env`:
   ```
   GROQ_API_KEY=your_actual_key_here
   ```
4. Optionally set a model:
   ```
   GROQ_MODEL=llama-3.3-70b-versatile
   ```

## How to Run

### Prerequisites
- Python 3.12 or higher
- A Groq API key (get one at console.groq.com)

### Steps

1. Clone the repository:
   ```
   git clone <repository-url>
   cd Beginner
   ```

2. Create and activate a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate     # Windows
   source venv/bin/activate  # Mac/Linux
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Set up your API key:
   ```
   cp .env.example .env
   # Edit .env and add your GROQ_API_KEY
   ```

5. Run the application:
   ```
   streamlit run app.py
   ```

6. The application opens in your browser at `http://localhost:8501`

## Example Usage

### Summarize Notes
1. Select "Summarize Notes" from the sidebar
2. Paste a paragraph of lecture notes (at least 50 characters)
3. Click "Generate Summary"
4. Read the bullet-point summary

### Generate Quiz
1. Select "Generate Quiz" from the sidebar
2. Paste your study notes
3. Choose the number of questions (3-10)
4. Click "Generate Quiz"
5. Test yourself with the generated questions and check the answer key

### Explain Concept
1. Select "Explain Concept" from the sidebar
2. Type a concept name (e.g., "Photosynthesis")
3. Click "Explain"
4. Read the structured explanation with definition, details, and example

### Improve Answer
1. Select "Improve Answer" from the sidebar
2. Enter the question you are answering
3. Paste your current answer
4. Click "Improve Answer"
5. Review the improved version and incorporate suggestions

## Limitations

- Requires an internet connection for API calls
- API responses depend on the quality and clarity of input
- The model may occasionally produce inaccurate information — always verify critical facts
- Rate limits apply based on your Groq API plan
- Input length is practically limited by the model's context window

## Future Improvements

- Add study session tracking and history
- Support file uploads for notes (PDF, TXT)
- Add spaced repetition scheduling for quizzes
- Include multiple language support
- Add export options for generated content
