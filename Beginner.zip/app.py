import sys
import streamlit as st
from prompts import (
    build_summarize_prompt,
    build_quiz_prompt,
    build_explain_prompt,
    build_improve_prompt,
)
from utils import call_groq

if __name__ == "__main__":
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        if get_script_run_ctx() is None:
            print("Please run this app with: streamlit run app.py")
            sys.exit(0)
    except Exception:
        print("Please run this app with: streamlit run app.py")
        sys.exit(0)

st.set_page_config(page_title="StudyMate AI", page_icon=":books:", layout="centered")

st.title("StudyMate AI")
st.markdown("Your AI-powered study assistant. Choose a tool below to get started.")

FEATURES = {
    "Summarize Notes": "Get a concise summary of your study notes",
    "Generate Quiz": "Create a practice quiz from your notes",
    "Explain Concept": "Get a clear explanation of any topic",
    "Improve Answer": "Strengthen and refine your written answer",
}

with st.sidebar:
    st.header("Choose a Tool")
    selected_feature = st.radio(
        "Select a study tool:",
        options=list(FEATURES.keys()),
        format_func=lambda x: x,
    )
    st.info(FEATURES[selected_feature])


def validate_non_empty(value, field_name):
    if not value or not value.strip():
        return f"Please enter {field_name}."
    return None


def validate_min_length(value, min_len, field_name):
    if value and len(value.strip()) < min_len:
        return f"{field_name} should be at least {min_len} characters."
    return None


def display_output(output):
    st.divider()
    st.subheader("Generated Output")
    st.markdown(output)


if selected_feature == "Summarize Notes":
    st.subheader("Summarize Notes")
    st.markdown("Paste your study notes below to get a clear, concise summary.")

    notes = st.text_area(
        "Your notes:",
        height=200,
        placeholder="Paste your lecture notes, textbook chapter, or study material here...",
    )

    if st.button("Generate Summary", type="primary"):
        error = validate_non_empty(notes, "your notes")
        if not error:
            error = validate_min_length(notes, 50, "Your notes")
        if error:
            st.warning(error)
        else:
            with st.spinner("Generating summary..."):
                try:
                    messages = build_summarize_prompt(notes)
                    result = call_groq(messages, temperature=0.5)
                    display_output(result)
                except RuntimeError as e:
                    st.error(str(e))


elif selected_feature == "Generate Quiz":
    st.subheader("Generate Quiz")
    st.markdown("Paste your notes and choose how many questions you want.")

    notes = st.text_area(
        "Your notes:",
        height=200,
        placeholder="Paste your study notes here to generate a quiz from them...",
    )

    num_questions = st.slider("Number of questions:", min_value=3, max_value=10, value=5)

    if st.button("Generate Quiz", type="primary"):
        error = validate_non_empty(notes, "your notes")
        if not error:
            error = validate_min_length(notes, 30, "Your notes")
        if error:
            st.warning(error)
        else:
            with st.spinner("Generating quiz..."):
                try:
                    messages = build_quiz_prompt(notes, num_questions)
                    result = call_groq(messages, temperature=0.7)
                    display_output(result)
                except RuntimeError as e:
                    st.error(str(e))


elif selected_feature == "Explain Concept":
    st.subheader("Explain Concept")
    st.markdown("Enter a concept or topic you want explained clearly.")

    concept = st.text_input(
        "Concept or topic:",
        placeholder="e.g., Neural Networks, Photosynthesis, Supply and Demand...",
    )

    if st.button("Explain", type="primary"):
        error = validate_non_empty(concept, "a concept or topic")
        if error:
            st.warning(error)
        else:
            with st.spinner("Generating explanation..."):
                try:
                    messages = build_explain_prompt(concept)
                    result = call_groq(messages, temperature=0.7)
                    display_output(result)
                except RuntimeError as e:
                    st.error(str(e))


elif selected_feature == "Improve Answer":
    st.subheader("Improve Answer")
    st.markdown(
        "Enter the question and your current answer. "
        "The AI will help you improve it while keeping your original intent."
    )

    question = st.text_input(
        "The question:",
        placeholder="e.g., Explain the causes of World War I...",
    )

    answer = st.text_area(
        "Your answer:",
        height=150,
        placeholder="Paste your current answer here...",
    )

    if st.button("Improve Answer", type="primary"):
        error = validate_non_empty(question, "the question")
        if not error:
            error = validate_non_empty(answer, "your answer")
        if error:
            st.warning(error)
        else:
            with st.spinner("Improving your answer..."):
                try:
                    messages = build_improve_prompt(question, answer)
                    result = call_groq(messages, temperature=0.5)
                    display_output(result)
                except RuntimeError as e:
                    st.error(str(e))
