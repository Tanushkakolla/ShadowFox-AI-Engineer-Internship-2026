def build_summarize_prompt(notes):
    return [
        {
            "role": "system",
            "content": (
                "You are a study assistant that summarizes academic notes. "
                "Given a set of notes, produce a clear and concise summary that captures "
                "the main ideas, key terms, and essential points. "
                "Use bullet points for clarity. "
                "Keep the summary under 300 words. "
                "Do not add information that is not present in the original notes."
            ),
        },
        {
            "role": "user",
            "content": f"Summarize the following notes:\n\n{notes}",
        },
    ]


def build_quiz_prompt(notes, num_questions=5):
    return [
        {
            "role": "system",
            "content": (
                "You are a study assistant that creates quizzes from study notes. "
                "Given a set of notes, generate a quiz with the specified number of questions. "
                "Use a mix of question types: multiple choice, true/false, and short answer. "
                "For multiple choice, provide 4 options labeled A through D. "
                "After all questions, provide an answer key. "
                "Questions should test understanding, not just recall. "
                "Format the output clearly with numbered questions."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Create a quiz with {num_questions} questions from the following notes:\n\n{notes}"
            ),
        },
    ]


def build_explain_prompt(concept):
    return [
        {
            "role": "system",
            "content": (
                "You are a friendly study assistant that explains concepts clearly. "
                "Given a concept or topic, provide a clear explanation suitable for a student. "
                "Structure your response as follows: "
                "1. A simple definition in 1-2 sentences. "
                "2. A detailed explanation in plain language. "
                "3. A real-world example or analogy. "
                "4. Why this concept is important. "
                "Avoid jargon unless you define it. "
                "Keep the explanation under 400 words."
            ),
        },
        {
            "role": "user",
            "content": f"Explain the following concept:\n\n{concept}",
        },
    ]


def build_improve_prompt(question, answer):
    return [
        {
            "role": "system",
            "content": (
                "You are a study assistant that helps improve student answers. "
                "Given a question and a student's answer, provide an improved version that: "
                "1. Preserves the student's original intent and key points. "
                "2. Adds missing important information. "
                "3. Improves clarity and structure. "
                "4. Uses more precise language where appropriate. "
                "5. Maintains an appropriate academic tone. "
                "Do not completely rewrite the answer in a different style. "
                "Build on what the student has already written."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Question: {question}\n\n"
                f"Student's answer: {answer}\n\n"
                "Please improve this answer while preserving the student's original intent."
            ),
        },
    ]
