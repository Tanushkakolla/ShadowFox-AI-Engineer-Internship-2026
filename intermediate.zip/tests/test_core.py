"""Focused tests for Milestone 2 core modules.

Run from the intermediate/ directory:
    python -m pytest tests/test_core.py -v
"""

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from chunker import Chunk, chunk_text
from config import CHUNK_OVERLAP, CHUNK_SIZE, EMBEDDING_DIM, TOP_K
from document_loader import DocumentLoadError, load_document
from embeddings import encode_documents, encode_query
from vector_store import VectorStore, VectorStoreError

DATA_DIR = Path(__file__).resolve().parent / "data"


def _make_pdf(text: str) -> bytes:
    """Build a minimal valid single-page PDF containing `text`."""
    escaped = text.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
    lines = escaped.split("\n")
    content_parts = ["BT /F1 12 Tf 50 750 Td"]
    for i, line in enumerate(lines):
        if i > 0:
            content_parts.append("0 -14 Td")
        content_parts.append(f"({line}) Tj")
    content_parts.append("ET")
    stream = "\n".join(content_parts).encode("latin-1")

    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
        b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]

    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for num, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{num} 0 obj\n".encode() + obj + b"\nendobj\n"

    xref_pos = len(out)
    out += f"xref\n0 {len(objects) + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_pos}\n%%EOF\n"
    ).encode()
    return bytes(out)


def _make_pdf_no_text() -> bytes:
    """Valid PDF page with an empty content stream (image-only style)."""
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >>",
        b"<< /Length 0 >>\nstream\n\nendstream",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for num, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{num} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref_pos = len(out)
    out += f"xref\n0 {len(objects) + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_pos}\n%%EOF\n"
    ).encode()
    return bytes(out)


# ---------------------------------------------------------------------------
# 1. PDF extraction
# ---------------------------------------------------------------------------
def test_pdf_extraction():
    pdf = _make_pdf("Hello PDF World.\nSecond line of the PDF.")
    text = load_document("notes.pdf", pdf)
    assert "Hello PDF World." in text
    assert "Second line of the PDF." in text


# ---------------------------------------------------------------------------
# 2. TXT extraction (utf-8 and cp1252)
# ---------------------------------------------------------------------------
def test_txt_extraction_utf8():
    data = (DATA_DIR / "sample_notes.txt").read_bytes()
    text = load_document("sample_notes.txt", data)
    assert "eight planets" in text


def test_txt_extraction_cp1252():
    data = "Café résumé – naïve.".encode("cp1252")
    text = load_document("french.txt", data)
    assert "Café" in text


# ---------------------------------------------------------------------------
# 3. Empty / invalid document handling
# ---------------------------------------------------------------------------
def test_unsupported_file_type():
    with pytest.raises(DocumentLoadError, match="Unsupported file type"):
        load_document("notes.md", b"# hello")


def test_empty_txt_file():
    with pytest.raises(DocumentLoadError, match="empty"):
        load_document("empty.txt", b"")


def test_whitespace_only_txt():
    with pytest.raises(DocumentLoadError, match="no content"):
        load_document("blank.txt", b"   \n\t  \n")


def test_corrupt_pdf():
    with pytest.raises(DocumentLoadError, match="corrupt|valid PDF|could not be read"):
        load_document("broken.pdf", b"this is not a pdf at all")


def test_pdf_with_no_extractable_text():
    with pytest.raises(DocumentLoadError, match="No extractable text"):
        load_document("scanned.pdf", _make_pdf_no_text())


# ---------------------------------------------------------------------------
# 4. Chunking and overlap
# ---------------------------------------------------------------------------
def test_chunking_basic_properties():
    text = ("The quick brown fox jumps over the lazy dog. " * 200).strip()
    chunks = chunk_text(text, "doc.txt", chunk_size=1000, chunk_overlap=200)

    assert len(chunks) >= 2
    assert all(isinstance(c, Chunk) for c in chunks)
    assert all(c.document_name == "doc.txt" for c in chunks)
    assert [c.chunk_id for c in chunks] == list(range(len(chunks)))
    for c in chunks[:-1]:
        assert len(c.text) == 1000
    assert len(chunks[-1].text) <= 1000
    assert len("".join(c.text for c in chunks)) >= len(text)  # nothing lost


def test_chunking_overlap_exact():
    text = "".join(str(i % 10) for i in range(3000))
    chunks = chunk_text(text, "digits.txt", chunk_size=1000, chunk_overlap=200)
    for a, b in zip(chunks, chunks[1:]):
        assert a.text[-200:] == b.text[:200]


def test_chunking_defaults_match_config():
    text = "x" * 2500
    chunks = chunk_text(text, "d.txt")
    assert CHUNK_SIZE == 1000
    assert CHUNK_OVERLAP == 200
    assert all(len(c.text) <= CHUNK_SIZE for c in chunks)


def test_chunking_empty_text():
    assert chunk_text("", "e.txt") == []
    assert chunk_text("   \n  ", "e.txt") == []


def test_chunking_invalid_overlap():
    with pytest.raises(ValueError):
        chunk_text("hello", "x.txt", chunk_size=100, chunk_overlap=100)
    with pytest.raises(ValueError):
        chunk_text("hello", "x.txt", chunk_size=0, chunk_overlap=0)


def test_chunking_crlf_normalized():
    text = "line one\r\nline two\r\nline three"
    chunks = chunk_text(text, "win.txt", chunk_size=100, chunk_overlap=0)
    assert "\r" not in chunks[0].text


# ---------------------------------------------------------------------------
# 5. Embedding dimensions / type
# ---------------------------------------------------------------------------
def test_embedding_dimensions_and_type():
    vecs = encode_documents(["first chunk", "second chunk"])
    assert vecs.shape == (2, EMBEDDING_DIM)
    assert vecs.dtype == np.float32

    q = encode_query("what is the largest planet?")
    assert q.shape == (EMBEDDING_DIM,)
    assert q.dtype == np.float32


def test_embedding_empty_inputs():
    from embeddings import EmbeddingError

    with pytest.raises(EmbeddingError):
        encode_documents([])
    with pytest.raises(EmbeddingError):
        encode_query("   ")


# ---------------------------------------------------------------------------
# 6. FAISS indexing
# ---------------------------------------------------------------------------
def test_faiss_indexing():
    store = VectorStore(dimension=EMBEDDING_DIM)
    assert store.count == 0

    texts = ["alpha about cats", "beta about dogs", "gamma about space"]
    vecs = encode_documents(texts)
    chunks = [Chunk(text=t, document_name="d.txt", chunk_id=i) for i, t in enumerate(texts)]
    store.add(vecs, chunks)

    assert store.count == 3


def test_index_rejects_mismatched_counts():
    store = VectorStore(dimension=EMBEDDING_DIM)
    vecs = encode_documents(["a", "b"])
    with pytest.raises(VectorStoreError, match="does not match"):
        store.add(vecs, [Chunk(text="a", document_name="d", chunk_id=0)])


def test_index_rejects_wrong_dimension():
    store = VectorStore(dimension=EMBEDDING_DIM)
    bad = np.ones((1, 8), dtype=np.float32)
    with pytest.raises(VectorStoreError, match="dimension"):
        store.add(bad, [Chunk(text="a", document_name="d", chunk_id=0)])


# ---------------------------------------------------------------------------
# 7. Similarity retrieval
# ---------------------------------------------------------------------------
def test_similarity_retrieval_orders_correctly():
    data = (DATA_DIR / "sample_notes.txt").read_text(encoding="utf-8")
    store = VectorStore(dimension=EMBEDDING_DIM)

    paragraphs = [p.strip() for p in data.split("\n\n") if p.strip()]
    para_chunks = [
        Chunk(text=p, document_name="planets.txt", chunk_id=i)
        for i, p in enumerate(paragraphs)
    ]
    store.add(encode_documents([c.text for c in para_chunks]), para_chunks)

    # also index fine-grained sentence chunks from the bulk text
    sentence_chunks = chunk_text(data, "planets_full.txt", chunk_size=200, chunk_overlap=40)
    store.add(encode_documents([c.text for c in sentence_chunks]), sentence_chunks)

    results = store.search(encode_query("Which planet has the most prominent rings?"), top_k=3)
    assert len(results) == 3
    assert all(-1.0 <= r.score <= 1.0 for r in results)
    assert results[0].score >= results[-1].score
    assert "Saturn" in results[0].text
    assert results[0].document_name in {"planets.txt", "planets_full.txt"}
    assert isinstance(results[0].chunk_id, int)


def test_top_k_larger_than_index():
    store = VectorStore(dimension=EMBEDDING_DIM)
    vecs = encode_documents(["only one chunk"])
    store.add(vecs, [Chunk(text="only one chunk", document_name="d", chunk_id=0)])
    results = store.search(encode_query("one chunk"), top_k=10)
    assert len(results) == 1


def test_invalid_top_k():
    store = VectorStore(dimension=EMBEDDING_DIM)
    store.add(encode_documents(["x"]), [Chunk(text="x", document_name="d", chunk_id=0)])
    with pytest.raises(VectorStoreError, match="top_k"):
        store.search(encode_query("x"), top_k=0)


# ---------------------------------------------------------------------------
# 8. Empty-index handling
# ---------------------------------------------------------------------------
def test_empty_index_search_returns_empty():
    store = VectorStore(dimension=EMBEDDING_DIM)
    assert store.search(encode_query("anything")) == []


def test_config_values():
    assert TOP_K == 4
    assert EMBEDDING_DIM == 384
