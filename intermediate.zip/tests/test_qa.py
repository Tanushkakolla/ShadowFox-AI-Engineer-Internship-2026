"""Focused tests for Milestone 3 grounded QA engine.

All Groq interactions are mocked; no real API calls are made.

Run from the intermediate/ directory:
    python -m pytest tests/test_qa.py -v
"""

import sys
from pathlib import Path
from types import SimpleNamespace

import groq
import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import qa_engine
from chunker import Chunk, chunk_text
from config import EMBEDDING_DIM, SIMILARITY_THRESHOLD, TOP_K
from embeddings import encode_documents, encode_query
from qa_engine import (
    NOT_FOUND_ANSWER,
    QAError,
    SYSTEM_PROMPT,
    answer_question,
    build_context,
)
from vector_store import RetrievedChunk, VectorStore

DATA_DIR = Path(__file__).resolve().parent / "data"


# ---------------------------------------------------------------------------
# Fake Groq client
# ---------------------------------------------------------------------------
class FakeGroqClient:
    """Minimal stand-in for groq.Groq capturing chat.completions.create calls."""

    def __init__(self, content="Mocked grounded answer.", error=None):
        self._content = content
        self._error = error
        self.calls = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        if self._error is not None:
            raise self._error
        message = SimpleNamespace(content=self._content)
        return SimpleNamespace(choices=[SimpleNamespace(message=message)])


class FakeStore:
    """Store stub returning fixed results (for threshold / validation tests)."""

    def __init__(self, results, count=1):
        self._results = results
        self.count = count

    def search(self, query_embedding, top_k=TOP_K):
        return self._results[:top_k]


def _source(doc="guide.txt", chunk_id=0, score=0.7, text="Paris is the capital of France."):
    return RetrievedChunk(
        text=text, document_name=doc, chunk_id=chunk_id, score=score
    )


def _groq_http_error(cls, status_code):
    request = httpx.Request("POST", "https://api.groq.com/v1/chat/completions")
    response = httpx.Response(status_code, request=request)
    return cls("mocked error", response=response, body=None)


def _two_document_store() -> VectorStore:
    notes = (DATA_DIR / "sample_notes.txt").read_text(encoding="utf-8")
    para_chunks = [
        Chunk(text=p.strip(), document_name="planets.txt", chunk_id=i)
        for i, p in enumerate(notes.split("\n\n"))
        if p.strip()
    ]
    sentences = chunk_text(
        "Mount Everest is the tallest mountain on Earth. "
        "The Amazon River flows through South America. "
        "Python is a popular programming language.",
        "geography.txt",
        chunk_size=120,
        chunk_overlap=30,
    )
    chunks = para_chunks + sentences
    store = VectorStore(dimension=EMBEDDING_DIM)
    store.add(encode_documents([c.text for c in chunks]), chunks)
    return store


# ---------------------------------------------------------------------------
# 1. Empty question
# ---------------------------------------------------------------------------
def test_empty_question_rejected():
    store = FakeStore([_source()])
    with pytest.raises(QAError, match="enter a question"):
        answer_question("", store, client=FakeGroqClient())
    with pytest.raises(QAError, match="enter a question"):
        answer_question("   ", store, client=FakeGroqClient())


# ---------------------------------------------------------------------------
# 2. Query before document processing
# ---------------------------------------------------------------------------
def test_query_before_processing_rejected():
    empty = VectorStore(dimension=EMBEDDING_DIM)
    with pytest.raises(QAError, match="No documents have been processed"):
        answer_question("what is this?", empty, client=FakeGroqClient())
    with pytest.raises(QAError, match="No documents have been processed"):
        answer_question("what is this?", None, client=FakeGroqClient())


# ---------------------------------------------------------------------------
# 3. Retrieval threshold rejection (Groq must NOT be called)
# ---------------------------------------------------------------------------
def test_threshold_rejection_skips_groq(monkeypatch):
    def _fail():
        raise AssertionError("_get_client must not be called below threshold")

    monkeypatch.setattr(qa_engine, "_get_client", _fail)

    low = FakeStore([_source(score=SIMILARITY_THRESHOLD - 0.1)])
    result = answer_question("obscure unrelated question?", low, client=None)
    assert result.found is False
    assert result.answer == NOT_FOUND_ANSWER
    assert result.sources == []
    assert result.best_score is not None
    assert result.best_score < SIMILARITY_THRESHOLD


def test_empty_search_result_rejected_without_groq(monkeypatch):
    monkeypatch.setattr(
        qa_engine, "_get_client", lambda: (_ for _ in ()).throw(AssertionError())
    )
    result = answer_question("anything", FakeStore([]), client=None)
    assert result.found is False
    assert result.answer == NOT_FOUND_ANSWER
    assert result.best_score is None


def test_threshold_boundary_is_configurable():
    assert qa_engine.SIMILARITY_THRESHOLD == SIMILARITY_THRESHOLD
    assert 0.0 < SIMILARITY_THRESHOLD < 1.0


# ---------------------------------------------------------------------------
# 4. Correct context construction
# ---------------------------------------------------------------------------
def test_context_construction_format():
    sources = [
        _source(doc="alpha.pdf", chunk_id=0, score=0.9, text="Alpha fact."),
        _source(doc="beta.txt", chunk_id=3, score=0.8, text="Beta fact."),
    ]
    context = build_context(sources)
    assert "[Document: alpha.pdf | Chunk: 0]\nAlpha fact." in context
    assert "[Document: beta.txt | Chunk: 3]\nBeta fact." in context
    # Only retrieved chunks, not whole documents
    assert context.count("[Document:") == 2


# ---------------------------------------------------------------------------
# 5. Grounding prompt
# ---------------------------------------------------------------------------
def test_grounding_system_prompt():
    assert "ONLY the document context" in SYSTEM_PROMPT
    assert "Do not use outside knowledge" in SYSTEM_PROMPT
    assert "Do not invent" in SYSTEM_PROMPT
    assert NOT_FOUND_ANSWER in SYSTEM_PROMPT
    assert "concise" in SYSTEM_PROMPT


# ---------------------------------------------------------------------------
# 6. Successful Groq response using retrieved context
# ---------------------------------------------------------------------------
def test_successful_response_sends_retrieved_context():
    sources = [
        _source(doc="caps.txt", chunk_id=0, score=0.88,
                text="Canberra is the capital of Australia."),
        _source(doc="caps.txt", chunk_id=1, score=0.72,
                text="Ottawa is the capital of Canada."),
    ]
    store = FakeStore(sources)
    client = FakeGroqClient(content="Canberra is the capital of Australia.")

    result = answer_question("What is the capital of Australia?", store, client=client)

    assert result.found is True
    assert result.answer == "Canberra is the capital of Australia."
    assert result.sources == sources
    assert result.best_score == 0.88

    assert len(client.calls) == 1
    call = client.calls[0]
    assert call["model"] == qa_engine.GROQ_MODEL

    messages = call["messages"]
    assert messages[0]["role"] == "system"
    assert messages[0]["content"] == SYSTEM_PROMPT
    assert messages[1]["role"] == "user"
    user_content = messages[1]["content"]
    # Retrieved chunks (with metadata) are in the prompt
    assert "Canberra is the capital of Australia." in user_content
    assert "[Document: caps.txt | Chunk: 0]" in user_content
    assert "Ottawa is the capital of Canada." in user_content
    assert "What is the capital of Australia?" in user_content
    # Raw question is never sent alone: context block precedes it
    assert user_content.index("Document context:") < user_content.index("Question:")


def test_empty_llm_response_raises():
    store = FakeStore([_source()])
    client = FakeGroqClient(content="   ")
    with pytest.raises(QAError, match="empty response"):
        answer_question("anything relevant", store, client=client)


# ---------------------------------------------------------------------------
# 7. Missing API key
# ---------------------------------------------------------------------------
def test_missing_api_key(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    store = FakeStore([_source(score=0.9)])
    with pytest.raises(QAError, match="GROQ_API_KEY is not set"):
        answer_question("capital of France?", store, client=None)


# ---------------------------------------------------------------------------
# 8. API authentication failure
# ---------------------------------------------------------------------------
def test_authentication_failure():
    client = FakeGroqClient(
        error=_groq_http_error(groq.AuthenticationError, 401)
    )
    store = FakeStore([_source(score=0.9)])
    with pytest.raises(QAError, match="authentication failed"):
        answer_question("capital of France?", store, client=client)


# ---------------------------------------------------------------------------
# 9. Rate-limit and other API failures
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "exc_cls,status,needle",
    [
        (groq.RateLimitError, 429, "rate limit"),
        (groq.InternalServerError, 500, "server error"),
        (groq.APIStatusError, 400, "unexpected error"),
    ],
)
def test_api_failures_map_to_friendly_errors(exc_cls, status, needle):
    client = FakeGroqClient(error=_groq_http_error(exc_cls, status))
    store = FakeStore([_source(score=0.9)])
    with pytest.raises(QAError, match=needle):
        answer_question("capital of France?", store, client=client)


def test_connection_failure_maps_to_friendly_error():
    request = httpx.Request("POST", "https://api.groq.com/v1/chat/completions")
    client = FakeGroqClient(
        error=groq.APIConnectionError(request=request)
    )
    store = FakeStore([_source(score=0.9)])
    with pytest.raises(QAError, match="connect"):
        answer_question("capital of France?", store, client=client)


def test_timeout_maps_to_friendly_error():
    request = httpx.Request("POST", "https://api.groq.com/v1/chat/completions")
    client = FakeGroqClient(error=groq.APITimeoutError(request=request))
    store = FakeStore([_source(score=0.9)])
    with pytest.raises(QAError, match="timed out"):
        answer_question("capital of France?", store, client=client)


def test_unexpected_exception_maps_to_friendly_error():
    client = FakeGroqClient(error=RuntimeError("boom: secret-key-12345"))
    store = FakeStore([_source(score=0.9)])
    with pytest.raises(QAError) as excinfo:
        answer_question("capital of France?", store, client=client)
    # No raw stack trace or secret leaked to the user
    assert "boom" not in str(excinfo.value)
    assert "secret-key-12345" not in str(excinfo.value)
    assert "Traceback" not in str(excinfo.value)


# ---------------------------------------------------------------------------
# 10. Multiple-document retrieval
# ---------------------------------------------------------------------------
def test_multiple_document_retrieval():
    store = _two_document_store()
    assert store.count > 2

    q = encode_query("What is the tallest mountain on Earth?")
    results = store.search(q, top_k=4)
    assert len(results) >= 1
    assert any(r.document_name == "geography.txt" for r in results)
    assert "Mount Everest" in results[0].text

    q2 = encode_query("Which planet has a Great Red Spot?")
    results2 = store.search(q2, top_k=4)
    assert any(r.document_name == "planets.txt" for r in results2)
    assert "Jupiter" in results2[0].text


def test_multiple_documents_combined_index_metadata():
    store = _two_document_store()
    doc_names = {r.document_name for r in store.search(
        encode_query("planets and mountains"), top_k=store.count
    )}
    assert doc_names == {"planets.txt", "geography.txt"}


# ---------------------------------------------------------------------------
# 11. Source metadata returned correctly
# ---------------------------------------------------------------------------
def test_source_metadata_returned():
    sources = [
        _source(doc="report.pdf", chunk_id=7, score=0.91, text="Revenue grew 12%."),
        _source(doc="report.pdf", chunk_id=2, score=0.65, text="Expenses fell 4%."),
    ]
    client = FakeGroqClient(content="Revenue grew 12%.")
    result = answer_question(
        "How much did revenue grow?",
        FakeStore(sources),
        client=client,
    )
    assert len(result.sources) == 2
    for src in result.sources:
        assert src.document_name == "report.pdf"
        assert isinstance(src.chunk_id, int)
        assert isinstance(src.score, float)
        assert src.text
    assert result.sources[0].chunk_id == 7
    assert result.sources[1].chunk_id == 2
    assert result.sources[0].score > result.sources[1].score
