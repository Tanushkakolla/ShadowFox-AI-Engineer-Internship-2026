"""End-to-end pipeline verification (Milestone 4, Tests A–D).

Runs the real ingestion → chunking → embedding → FAISS → threshold pipeline.
Groq generation is mocked (no API key required): the fake client verifies
that the request actually carries the retrieved context and grounding prompt.

Run from the intermediate/ directory:
    python -m pytest tests/test_e2e.py -v
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from chunker import chunk_text
from config import EMBEDDING_DIM, SIMILARITY_THRESHOLD
from document_loader import DocumentLoadError, load_document
from embeddings import encode_documents
from qa_engine import NOT_FOUND_ANSWER, QAError, answer_question
from test_core import _make_pdf
from test_qa import FakeGroqClient
from vector_store import VectorStore

DATA_DIR = Path(__file__).resolve().parent / "data"

DOC_A_TEXT = """Company Aurora Founded in 2015.
Aurora is a robotics company headquartered in Toronto.
Its flagship product is the Atlas-M warehouse robot.
Aurora employs 420 people as of 2025.
Revenue in 2024 was 95 million dollars.
"""

DOC_B_TEXT = """Mount Everest is 8849 meters tall, the tallest mountain on Earth.
The Amazon River flows through Brazil, Peru, and Colombia.
The Sahara is the largest hot desert in the world.
"""


def _build_store(files: list[tuple[str, bytes]]) -> tuple[VectorStore, list[str]]:
    """Full document processing pipeline: validate → extract → chunk → embed → index."""
    chunks = []
    names = []
    for name, data in files:
        text = load_document(name, data)
        file_chunks = chunk_text(text, name)
        assert file_chunks, f"no chunks from {name}"
        chunks.extend(file_chunks)
        names.append(name)
    store = VectorStore(dimension=EMBEDDING_DIM)
    store.add(encode_documents([c.text for c in chunks]), chunks)
    return store, names


# ---------------------------------------------------------------------------
# Test A — Supported question (full pipeline: PDF → answer + sources)
# ---------------------------------------------------------------------------
def test_a_supported_question_full_pipeline():
    pdf_bytes = _make_pdf(DOC_A_TEXT)
    store, names = _build_store([("aurora_report.pdf", pdf_bytes)])
    assert names == ["aurora_report.pdf"]
    assert store.count >= 1

    client = FakeGroqClient(
        content="Aurora is headquartered in Toronto."
    )
    result = answer_question(
        "Where is Aurora headquartered?", store, client=client
    )

    # Grounded answer generated after retrieval
    assert result.found is True
    assert result.answer == "Aurora is headquartered in Toronto."

    # Source context available with full metadata
    assert len(result.sources) >= 1
    top = result.sources[0]
    assert top.document_name == "aurora_report.pdf"
    assert isinstance(top.chunk_id, int)
    assert isinstance(top.score, float)
    assert top.score >= SIMILARITY_THRESHOLD
    assert "Toronto" in top.text

    # Groq request contained retrieved context (not the raw question alone)
    call = client.calls[0]
    user_content = call["messages"][1]["content"]
    assert "Toronto" in user_content
    assert "[Document: aurora_report.pdf | Chunk:" in user_content
    assert "Where is Aurora headquartered?" in user_content
    assert "ONLY the document context" in call["messages"][0]["content"]


# ---------------------------------------------------------------------------
# Test B — Unsupported question (must refuse, not answer from model memory)
# ---------------------------------------------------------------------------
def test_b_unsupported_question_refused():
    store, _ = _build_store([("aurora_report.txt", DOC_A_TEXT.encode("utf-8"))])

    # A question clearly unrelated to the document.
    client = FakeGroqClient(content="This should never be reached.")
    result = answer_question(
        "What is the recipe for a chocolate cake with hazelnuts?",
        store,
        client=client,
    )

    if not result.found:
        # Threshold gate refused before Groq was called
        assert result.answer == NOT_FOUND_ANSWER
        assert result.sources == []
        assert result.best_score is not None
        assert result.best_score < SIMILARITY_THRESHOLD
        assert client.calls == []
    else:
        # Score happened to clear the threshold: grounding layers must still
        # constrain the model — strict system prompt + retrieved-only context.
        assert client.calls, "Groq must be called if threshold passed"
        system = client.calls[0]["messages"][0]["content"]
        assert "Do not use outside knowledge" in system
        assert NOT_FOUND_ANSWER in system
        user = client.calls[0]["messages"][1]["content"]
        assert "Document context:" in user


# ---------------------------------------------------------------------------
# Test C — Invalid input
# ---------------------------------------------------------------------------
def test_c1_empty_question():
    store, _ = _build_store([("aurora_report.txt", DOC_A_TEXT.encode("utf-8"))])
    with pytest.raises(QAError, match="enter a question"):
        answer_question("", store, client=FakeGroqClient())
    with pytest.raises(QAError, match="enter a question"):
        answer_question("   \t ", store, client=FakeGroqClient())


def test_c2_unsupported_file():
    with pytest.raises(DocumentLoadError, match="Unsupported file type"):
        load_document("report.docx", b"fake binary content")
    with pytest.raises(DocumentLoadError, match="Unsupported file type"):
        load_document("image.png", b"\x89PNG not really")


def test_c3_empty_document():
    with pytest.raises(DocumentLoadError, match="empty"):
        load_document("empty.txt", b"")
    with pytest.raises(DocumentLoadError, match="no content"):
        load_document("blank.txt", b"  \n \t \n")


def test_c4_query_before_processing():
    empty_store = VectorStore(dimension=EMBEDDING_DIM)
    with pytest.raises(QAError, match="No documents have been processed"):
        answer_question("anything?", empty_store, client=FakeGroqClient())


# ---------------------------------------------------------------------------
# Test D — Multiple documents (answer lives in only one)
# ---------------------------------------------------------------------------
def test_d_multiple_documents_correct_source():
    store, names = _build_store(
        [
            ("aurora_report.txt", DOC_A_TEXT.encode("utf-8")),
            ("geography_notes.txt", DOC_B_TEXT.encode("utf-8")),
        ]
    )
    assert set(names) == {"aurora_report.txt", "geography_notes.txt"}
    assert store.count >= 2

    client = FakeGroqClient(content="Mount Everest is 8849 meters tall.")
    result = answer_question(
        "How tall is Mount Everest?", store, client=client
    )

    assert result.found is True
    # Correct document retrieved and displayed
    assert result.sources[0].document_name == "geography_notes.txt"
    assert "8849" in result.sources[0].text
    # The company document is not the top source for this question
    assert all(
        s.document_name != "aurora_report.txt" or s.score < result.sources[0].score
        for s in result.sources
    )
    # Source metadata intact for display
    for s in result.sources:
        assert s.document_name in {"aurora_report.txt", "geography_notes.txt"}
        assert isinstance(s.chunk_id, int)
        assert 0.0 <= s.score <= 1.0 or -1.0 <= s.score <= 1.0

    # Answer grounded in the retrieved chunk text
    user_content = client.calls[0]["messages"][1]["content"]
    assert "[Document: geography_notes.txt | Chunk:" in user_content
    assert "8849" in user_content
