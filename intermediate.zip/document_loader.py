"""Document text extraction for PDF and TXT files."""

from io import BytesIO

from pypdf import PdfReader
from pypdf.errors import PdfReadError

from config import SUPPORTED_EXTENSIONS


class DocumentLoadError(Exception):
    """Raised when a document cannot be loaded, validated, or extracted."""


def _decode_txt(data: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _extract_pdf(data: bytes) -> str:
    try:
        reader = PdfReader(BytesIO(data))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception as exc:
                raise DocumentLoadError(
                    "The PDF is encrypted and could not be opened."
                ) from exc
        if len(reader.pages) == 0:
            raise DocumentLoadError("The PDF contains no pages.")
        parts = []
        for page in reader.pages:
            parts.append(page.extract_text() or "")
        return "\n".join(parts)
    except DocumentLoadError:
        raise
    except PdfReadError as exc:
        raise DocumentLoadError(
            "The PDF file is corrupt or is not a valid PDF."
        ) from exc
    except Exception as exc:
        raise DocumentLoadError(
            "The PDF file could not be read."
        ) from exc


def load_document(file_name: str, data: bytes) -> str:
    """Validate a file and return its extracted text.

    Raises DocumentLoadError with a user-facing message on any failure.
    """
    if not file_name or "." not in file_name:
        raise DocumentLoadError(
            "Unsupported file type. Please upload a PDF or TXT file."
        )

    extension = "." + file_name.rsplit(".", 1)[1].lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise DocumentLoadError(
            f"Unsupported file type '{extension}'. Only PDF and TXT files are allowed."
        )

    if not data:
        raise DocumentLoadError("The uploaded file is empty (0 bytes).")

    if extension == ".pdf":
        text = _extract_pdf(data)
        if not text.strip():
            raise DocumentLoadError(
                "No extractable text found in the PDF. It may be a scanned or "
                "image-only PDF, which is not supported (no OCR)."
            )
        return text

    text = _decode_txt(data)
    if not text.strip():
        raise DocumentLoadError("The text file contains no content.")
    return text
