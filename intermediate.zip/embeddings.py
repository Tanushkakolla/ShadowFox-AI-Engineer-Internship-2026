"""SentenceTransformer embedding wrapper with a cached model (singleton)."""

import numpy as np
from typing import TYPE_CHECKING

from config import EMBEDDING_MODEL

if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer

_model: 'SentenceTransformer | None' = None


class EmbeddingError(Exception):
    """Raised when the embedding model fails to load or encode text."""


def _get_model() -> 'SentenceTransformer':
    global _model
    if _model is None:
        try:
            from sentence_transformers import SentenceTransformer
            _model = SentenceTransformer(EMBEDDING_MODEL)
        except Exception as exc:
            raise EmbeddingError(
                f"Failed to load embedding model '{EMBEDDING_MODEL}'."
            ) from exc
    return _model


def embedding_dimension() -> int:
    return int(_get_model().get_sentence_embedding_dimension())


def encode_documents(texts: list[str]) -> np.ndarray:
    """Encode chunk texts into a (n, dim) float32 array for FAISS."""
    if not texts:
        raise EmbeddingError("No text provided to embed.")
    model = _get_model()
    try:
        vectors = model.encode(
            list(texts),
            convert_to_numpy=True,
            show_progress_bar=False,
            normalize_embeddings=False,
        )
    except Exception as exc:
        raise EmbeddingError("Failed to generate document embeddings.") from exc
    return np.asarray(vectors, dtype=np.float32)


def encode_query(text: str) -> np.ndarray:
    """Encode a single query into a (dim,) float32 vector for FAISS."""
    if not text or not text.strip():
        raise EmbeddingError("Query text is empty.")
    model = _get_model()
    try:
        vector = model.encode(
            text,
            convert_to_numpy=True,
            show_progress_bar=False,
            normalize_embeddings=False,
        )
    except Exception as exc:
        raise EmbeddingError("Failed to generate query embedding.") from exc
    return np.asarray(vector, dtype=np.float32)
