"""In-memory FAISS vector store using inner-product (cosine) search."""

from dataclasses import dataclass

import faiss
import numpy as np

from chunker import Chunk
from config import EMBEDDING_DIM, TOP_K


class VectorStoreError(Exception):
    """Raised on invalid indexing or search operations."""


@dataclass(frozen=True)
class RetrievedChunk:
    text: str
    document_name: str
    chunk_id: int
    score: float


class VectorStore:
    """FAISS IndexFlatIP over L2-normalized vectors (= cosine similarity)."""

    def __init__(self, dimension: int = EMBEDDING_DIM):
        self._dimension = dimension
        self._index = faiss.IndexFlatIP(dimension)
        self._chunks: list[Chunk] = []

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def count(self) -> int:
        return int(self._index.ntotal)

    def add(self, embeddings: np.ndarray, chunks: list[Chunk]) -> None:
        vectors = np.array(
            np.atleast_2d(np.asarray(embeddings, dtype=np.float32)), copy=True
        )
        if vectors.shape[0] == 0:
            return
        if vectors.shape[0] != len(chunks):
            raise VectorStoreError(
                f"Embedding count ({vectors.shape[0]}) does not match "
                f"chunk count ({len(chunks)})."
            )
        if vectors.shape[1] != self._dimension:
            raise VectorStoreError(
                f"Embedding dimension {vectors.shape[1]} does not match "
                f"index dimension {self._dimension}."
            )
        if not np.isfinite(vectors).all():
            raise VectorStoreError(
                "Embeddings contain NaN or infinite values and cannot be indexed."
            )
        faiss.normalize_L2(vectors)
        self._index.add(vectors)
        self._chunks.extend(chunks)

    def search(
        self, query_embedding: np.ndarray, top_k: int = TOP_K
    ) -> list[RetrievedChunk]:
        if self._index.ntotal == 0:
            return []
        if top_k < 1:
            raise VectorStoreError("top_k must be at least 1.")

        query = np.asarray(query_embedding, dtype=np.float32)
        if query.ndim == 1:
            query = query.reshape(1, -1)
        elif query.ndim != 2 or query.shape[0] != 1:
            raise VectorStoreError(
                "Query embedding must be a single vector of shape (dim,) or (1, dim)."
            )
        if query.shape[1] != self._dimension:
            raise VectorStoreError(
                f"Query dimension {query.shape[1]} does not match "
                f"index dimension {self._dimension}."
            )
        if not np.isfinite(query).all():
            raise VectorStoreError(
                "Query embedding contains NaN or infinite values."
            )

        query = np.array(query, copy=True)
        faiss.normalize_L2(query)

        k = min(top_k, self._index.ntotal)
        scores, indices = self._index.search(query, k)

        results: list[RetrievedChunk] = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            chunk = self._chunks[int(idx)]
            results.append(
                RetrievedChunk(
                    text=chunk.text,
                    document_name=chunk.document_name,
                    chunk_id=chunk.chunk_id,
                    score=float(score),
                )
            )
        return results
