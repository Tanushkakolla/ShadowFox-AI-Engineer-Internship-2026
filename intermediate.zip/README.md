# Document Q&A Assistant

A retrieval-based question answering assistant for PDF and TXT documents. Upload documents, ask questions, and receive answers grounded in the uploaded content — with the supporting source chunks shown for every answer.

## Problem statement

When users have one or more documents (reports, notes, manuals), they often need specific answers buried inside them. Sending a question straight to a large language model risks an answer built from the model's general knowledge rather than the actual documents — confident, fluent, and wrong for this context. The challenge is to answer **only** from the uploaded content and to show the evidence behind each answer.

## Solution

This application implements a classic retrieval-augmented question answering pipeline:

1. Documents are uploaded and their text is extracted.
2. Text is split into overlapping chunks.
3. Chunks are embedded locally and indexed in FAISS.
4. A question is embedded and searched against the index.
5. The most similar chunks are retrieved, checked against a similarity threshold, and passed to the Groq language model as the **only** permitted source of information.
6. The answer is displayed together with the retrieved supporting chunks (document name, chunk ID, similarity score, text).

If the retrieved context is not similar enough to the question, the language model is not called and the user is told the answer could not be found in the uploaded documents.

## Features

- **PDF/TXT upload** — multiple files at once
- **Text extraction** — via `pypdf` (PDF) and encoding-safe text decoding (TXT)
- **Document chunking** — fixed-size windows with overlap, deterministic and explainable
- **Embedding generation** — local `sentence-transformers/all-MiniLM-L6-v2` (384 dimensions)
- **FAISS similarity search** — in-memory `IndexFlatIP` cosine search
- **Grounded question answering** — Groq LLM restricted to retrieved context
- **Retrieved source context** — every answer shows document name, chunk ID, similarity score, and chunk text
- **Multiple-document support** — one combined index, per-chunk document metadata preserved
- **Input validation** — empty questions, unsupported files, empty/corrupt/scanned PDFs
- **API/error handling** — missing key, auth failure, rate limit, timeout, connection, and server errors surface as friendly messages (never stack traces or secrets)

## Architecture

```
Upload
  → Extraction
    → Chunking
      → Embeddings
        → FAISS
          → Query Embedding
            → Similarity Retrieval
              → Context
                → Groq
                  → Grounded Answer + Sources
```

## Document processing workflow

1. **File validation** — extension must be `.pdf` or `.txt`; 0-byte files are rejected with a clear message.
2. **Text extraction** — PDFs are parsed with `pypdf` (encrypted-empty-password handled; corrupt files rejected; PDFs with no extractable text are reported as unsupported because OCR is not implemented). TXT files are decoded trying `utf-8-sig`, `utf-8`, then `cp1252`, with a lossy fallback. Empty/whitespace-only content is rejected.
3. **Chunking** — text is split into overlapping character windows (see [Chunking strategy](#chunking-strategy)). Each chunk keeps its document name and chunk ID.
4. **Embedding generation** — all chunks are embedded in one batch as `float32` vectors of dimension 384.
5. **Vector indexing** — vectors are L2-normalized and added to a FAISS `IndexFlatIP` index that stores chunk metadata alongside vectors. Indexing only runs when the user clicks **Process documents**; unchanged document sets are not reprocessed.

## Query workflow

1. **User question** — validated as non-empty; querying before documents are processed is blocked in the UI and in the QA engine.
2. **Question embedding** — the same embedding model encodes the question into a 384-dimension vector.
3. **Similarity search** — FAISS inner-product search over normalized vectors (cosine similarity).
4. **Top-K retrieval** — the top **4** chunks are retrieved (`TOP_K = 4` in `config.py`). Four is a small, focused context: enough for multi-fact questions, small enough to keep the prompt readable and reduce irrelevant content.
5. **Similarity threshold** — if the best score is below `SIMILARITY_THRESHOLD` (0.25), the pipeline stops here: the LLM is **not** called and a clear "not found in the uploaded documents" response is returned.
6. **Context construction** — only the retrieved chunks are formatted as `[Document: name | Chunk: ID]` + text. Whole documents are never sent to the model.
7. **Groq generation** — a strict system prompt plus the context and question are sent to the configured Groq model (`llama-3.3-70b-versatile`).
8. **Source display** — the answer is shown with expandable cards for each supporting chunk: document name, chunk ID, similarity score, and text.

## Chunking strategy

| Setting | Value |
|---|---|
| Chunk size | **1000 characters** |
| Overlap | **200 characters** |

- **How it works:** a sliding window moves `chunk_size − overlap = 800` characters at a time, so consecutive chunks share exactly 200 characters. The behavior is deterministic: the same input always produces the same chunks.
- **Why overlap:** boundaries are arbitrary; overlap keeps sentences or ideas that straddle a boundary present in both neighboring chunks so a query still matches the right context.
- **Why these values:** 1000 characters (~150–250 words) is a readable, self-contained section that fits comfortably in the prompt with `TOP_K = 4`; 200 characters (20% of the chunk) is enough to preserve boundary context without duplicating too much text. They are sensible defaults for a student project with mixed document lengths.
- **These values are not claimed to be universally optimal.** Optimal chunk size depends on document type, embedding model, and query style. They are centralized in `config.py` so they can be tuned and re-evaluated (see [Limitations](#limitations)). Chunking quality directly affects retrieval: chunks that are too large dilute the semantic signal of embedding; chunks that are too small lose surrounding context and fragment answers.

## Embedding approach

| Setting | Value |
|---|---|
| Model | `sentence-transformers/all-MiniLM-L6-v2` |
| Dimension | 384 |
| Generation | Local (CPU), no embedding API |

- Encoded with `SentenceTransformer.encode(...)` and returned as FAISS-compatible `float32` arrays. The model is loaded **once** per process and cached (singleton in `embeddings.py`).
- **Why local:** the task requires no external embedding API — embeddings are generated entirely on this machine. A local model keeps the pipeline free, private (document text never leaves the machine for embedding), reproducible, and simple to run in a student environment. MiniLM-L6 is a well-known, lightweight sentence embedding model that is fast on CPU with good quality for semantic search on English text.

## Vector search

| Setting | Value |
|---|---|
| Library | FAISS (`faiss-cpu`) |
| Index | `IndexFlatIP` (exact inner product) |
| Normalization | L2 before indexing and before each query |
| Top-K | 4 |

- L2-normalized vectors have unit length, so the inner product equals the **cosine similarity**: `dot(a, b) = ‖a‖‖b‖ cos θ = cos θ` when `‖a‖ = ‖b‖ = 1`.
- `IndexFlatIP` performs exhaustive (exact) search — ideal for the corpus sizes of this project (hundreds to a few thousand chunks) with no approximate-search tuning needed.
- Scores returned to the user are cosine similarities in roughly `[-1, 1]`, where higher means more similar.

## Grounding strategy

Three independent layers keep answers tied to the documents:

1. **Retrieval-only context** — the language model never receives the raw question alone. Its user message always contains the retrieved chunks (with document/chunk labels) followed by the question. The model is structurally unable to "answer from memory" about data that was never sent.
2. **Strict grounding prompt** — the system prompt requires answering only from the supplied context, forbids outside knowledge and invention, mandates the exact refusal phrase when the context is insufficient, and asks for concise answers.
3. **Similarity threshold gate (pre-LLM)** — if the best cosine score is below 0.25, Groq is not called at all and the user gets a clear "answer could not be found in the uploaded documents" response, with the UI noting that the score fell below threshold.

Together these **reduce** unsupported answers: layer 3 blocks clearly unrelated questions before generation, layer 1 removes access to off-document facts, and layer 2 controls behavior when retrieved context is only partially relevant. **They do not completely eliminate hallucination** — if irrelevant chunks score above the threshold, the model may still misread them; that is a known limitation of retrieval-based systems at this level.

## Error handling

All user-facing errors are plain messages; stack traces and secrets are never shown.

| Failure | Behavior |
|---|---|
| No documents uploaded / query before processing | UI guard + `QAError`: process documents first |
| Empty or whitespace-only question | UI warning + `QAError` |
| Unsupported file type | `DocumentLoadError` naming the extension |
| Empty file / whitespace-only text | `DocumentLoadError` |
| Corrupt PDF | `DocumentLoadError` |
| PDF with no extractable text (scanned/image-only) | `DocumentLoadError` explaining OCR is not supported |
| Uploaded file set changed after indexing | UI warning; query blocked until reprocessing |
| Embedding failure | `EmbeddingError` → friendly `QAError`/UI message |
| Vector search failure | `VectorStoreError` → friendly `QAError` |
| Missing `GROQ_API_KEY` | `QAError` pointing at `.env` / `.env.example` |
| Invalid API key (auth error) | `QAError`: authentication failed, check the key |
| Rate limit | `QAError`: wait and retry |
| Timeout | `QAError`: request timed out |
| Connection failure | `QAError`: check internet connection |
| Groq server error (5xx) | `QAError`: try again shortly |
| Unexpected API/program error | Generic `QAError` — no stack trace, no key material |
| Empty LLM response | `QAError` |
| No sufficiently relevant context | Refusal response; LLM not called (threshold) |

## Security

- The Groq API key lives only in a local **`.env`** file (see `.env.example` for the placeholder).
- **`.env` is ignored by Git** (listed in `.gitignore`) and is never committed.
- `.env.example` contains only `GROQ_API_KEY=your_groq_api_key_here` — no real key.
- No secrets are hard-coded anywhere in the source.
- Document text is embedded locally; only retrieved chunks + your question are sent to Groq for answer generation.

## Limitations

- **Scanned/image-only PDFs are not supported** — text extraction returns nothing and the app reports this clearly. OCR was intentionally not implemented (out of Intermediate scope).
- **`SIMILARITY_THRESHOLD = 0.25` is a starting point** that requires further tuning against real documents; too low admits irrelevant context, too high causes unnecessary refusals.
- **The embedding model downloads on first use** (~90 MB from Hugging Face); subsequent runs use the local cache.
- **No browser-level automated UI tests** — the UI logic is exercised via module-level tests and manual verification; automated tests cover the pipeline modules, not Selenium/Playwright flows.
- **Live Groq behavior depends on a valid API key** — automated tests mock the Groq client; end-to-end generation with the real API requires your own `GROQ_API_KEY`.

## Setup instructions

```bash
# 1. From this directory, create and activate a virtual environment (recommended)
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS/Linux

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create your .env file
copy .env.example .env         # Windows
# cp .env.example .env         # macOS/Linux

# 4. Edit .env and set your real Groq key (get one at console.groq.com)
#    GROQ_API_KEY=gsk_...

# 5. Run the application
streamlit run app.py
```

Then in the browser:

6. Upload one or more PDF/TXT files.
7. Click **Process documents** and wait for the chunk/index summary.
8. Type a question and click **Get answer** — read the answer and expand the source cards.

## Example usage

**Document:** a short PDF containing facts such as *"The Eiffel Tower was completed in 1889 and is located in Paris."*

**Supported question:**

> *Where is the Eiffel Tower located?*

→ Answer: *Paris* — with a source card showing `eiffel.pdf | Chunk 0 | Score 0.8x` and the sentence above.

**Unsupported question (threshold gate):**

> *What is the recipe for chocolate cake?*

→ Response: *"The answer could not be found in the uploaded documents."* — the UI notes the best similarity score was below the threshold and the language model was not called.

**Multi-document question:**

> Upload `planets.txt` and `geography.txt`, then ask *"How tall is Mount Everest?"*

→ The top source is `geography.txt` with the chunk containing the height; `planets.txt` chunks are not cited for that fact.

## Project structure

```
intermediate/
├── app.py               # Streamlit UI (upload → process → ask → answer + sources)
├── config.py            # All tunable constants (model, chunking, top-k, threshold)
├── document_loader.py   # PDF/TXT extraction and validation
├── chunker.py           # Deterministic chunking with overlap + metadata
├── embeddings.py        # Cached SentenceTransformer wrapper
├── vector_store.py      # FAISS IndexFlatIP + cosine search
├── qa_engine.py         # Retrieval → threshold → Groq grounded generation
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
└── tests/
    ├── test_core.py     # Loader, chunking, embeddings, FAISS tests
    ├── test_qa.py       # Grounding, threshold, API-error tests (Groq mocked)
    ├── test_e2e.py      # End-to-end pipeline tests (Tests A–D)
    └── data/
        └── sample_notes.txt
```

## Running tests

```bash
python -m pytest tests/ -v
```

All automated tests run offline with the Groq client mocked; no API key is required for the test suite.
