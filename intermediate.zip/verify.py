import time
import sys
import os

print("--- 1. STARTUP AND IMPORT TIME ---")
t0 = time.perf_counter()
import app
t1 = time.perf_counter()
import_time = t1 - t0
print(f"app.py import time: {import_time:.4f}s")

from document_loader import load_document
from chunker import chunk_text
from embeddings import encode_documents, encode_query, _get_model
from vector_store import VectorStore
from qa_engine import answer_question

# Create test documents
with open("test_grounding.txt", "w", encoding="utf-8") as f:
    f.write("The project deadline is 15 October 2026.\nThe CEO's name is John Doe, but his phone number is kept secret.")

print("\n--- 2. DOCUMENT PROCESSING TIME ---")
class DummyUploadedFile:
    def __init__(self, name, content):
        self.name = name
        self.content = content
        self.size = len(content)
    def getvalue(self):
        return self.content

dummy_file = DummyUploadedFile("test_grounding.txt", open("test_grounding.txt", "rb").read())

t0 = time.perf_counter()
text = load_document(dummy_file.name, dummy_file.getvalue())
t1 = time.perf_counter()
doc_load_time = t1 - t0
print(f"Document load time: {doc_load_time:.4f}s")

t0 = time.perf_counter()
chunks = chunk_text(text, dummy_file.name)
t1 = time.perf_counter()
chunk_time = t1 - t0
print(f"Chunking time: {chunk_time:.4f}s")

print("\n--- 3. EMBEDDING INITIALIZATION & GENERATION TIME ---")
t0 = time.perf_counter()
_get_model()  # force initialization
t1 = time.perf_counter()
model_init_time = t1 - t0
print(f"Model initialization time (Lazy load): {model_init_time:.4f}s")

t0 = time.perf_counter()
embeddings = encode_documents([c.text for c in chunks])
t1 = time.perf_counter()
embed_gen_time = t1 - t0
print(f"Embedding generation time: {embed_gen_time:.4f}s")

t0 = time.perf_counter()
store = VectorStore()
store.add(embeddings, chunks)
t1 = time.perf_counter()
vector_store_time = t1 - t0
print(f"Vector store add time: {vector_store_time:.4f}s")

print("\n--- 4. QUERY AND RETRIEVAL TIME ---")
query = "What is the project deadline?"
t0 = time.perf_counter()
q_embed = encode_query(query)
t1 = time.perf_counter()
q_embed_time = t1 - t0
print(f"Query embedding time: {q_embed_time:.4f}s")

t0 = time.perf_counter()
retrieved = store.search(q_embed)
t1 = time.perf_counter()
retrieval_time = t1 - t0
print(f"FAISS retrieval time: {retrieval_time:.4f}s")
print("Retrieved chunks:")
for c in retrieved:
    print(f" - [{c.score:.4f}] {c.text}")

print("\n--- 5. GROUNDING AND ANSWER GENERATION ---")
t0 = time.perf_counter()
result1 = answer_question(query, store)
t1 = time.perf_counter()
ans_time1 = t1 - t0
print(f"Q: {query}")
print(f"A: {result1.answer}")
print(f"Time: {ans_time1:.4f}s")

query2 = "What is the CEO's phone number?"
t0 = time.perf_counter()
result2 = answer_question(query2, store)
t1 = time.perf_counter()
ans_time2 = t1 - t0
print(f"\nQ: {query2}")
print(f"A: {result2.answer}")
print(f"Time: {ans_time2:.4f}s")

print("\n--- SUMMARY PERF ---")
print(f"Import time: {import_time:.4f}s")
print(f"Model Init time: {model_init_time:.4f}s")
print(f"Doc Processing time (txt): {(doc_load_time+chunk_time+embed_gen_time+vector_store_time):.4f}s")
print(f"Query + Retrieval time: {(q_embed_time+retrieval_time):.4f}s")
print(f"Answer Gen time: {ans_time1:.4f}s")
