"""Streamlit interface for the document-based Q&A assistant."""

import streamlit as st
from dotenv import load_dotenv

from chunker import chunk_text
from config import CHUNK_OVERLAP, CHUNK_SIZE, TOP_K
from document_loader import DocumentLoadError, load_document
from embeddings import EmbeddingError, encode_documents
from qa_engine import QAError, QAResult, answer_question
from vector_store import VectorStore, VectorStoreError

load_dotenv()

st.set_page_config(page_title="Document Q&A Assistant", page_icon="📄", layout="wide")

st.title("📄 Document Q&A Assistant")
st.caption(
    "Upload PDF or TXT documents, then ask questions answered only "
    "from the uploaded content."
)

# --------------------------------------------------------------------------
# Session state
# --------------------------------------------------------------------------
if "store" not in st.session_state:
    st.session_state.store = None
if "processed_names" not in st.session_state:
    st.session_state.processed_names = []
if "chunk_count" not in st.session_state:
    st.session_state.chunk_count = 0
if "processed_signature" not in st.session_state:
    st.session_state.processed_signature = None
if "last_result" not in st.session_state:
    st.session_state.last_result = None


def _signature(files) -> tuple:
    return tuple(sorted((f.name, f.size) for f in files))


def _process_documents(files):
    """Extract, chunk, and index all processable files.

    Returns (store, ok_names, chunk_count, errors). store is None when
    no file could be processed (state is left unchanged by the caller).
    """
    all_chunks = []
    ok_names = []
    errors = []

    for f in files:
        try:
            text = load_document(f.name, f.getvalue())
            file_chunks = chunk_text(
                text,
                f.name,
                chunk_size=CHUNK_SIZE,
                chunk_overlap=CHUNK_OVERLAP,
            )
            if not file_chunks:
                raise DocumentLoadError(
                    "No content remained after chunking."
                )
            all_chunks.extend(file_chunks)
            ok_names.append(f.name)
        except DocumentLoadError as exc:
            errors.append(f"**{f.name}**: {exc}")

    if not all_chunks:
        return None, ok_names, 0, errors

    try:
        vectors = encode_documents([c.text for c in all_chunks])
        store = VectorStore()
        store.add(vectors, all_chunks)
    except (EmbeddingError, VectorStoreError) as exc:
        errors.append(f"**Indexing failed**: {exc}")
        return None, ok_names, 0, errors

    return store, ok_names, len(all_chunks), errors


# --------------------------------------------------------------------------
# 1. Document section
# --------------------------------------------------------------------------
st.header("1. Documents")

uploaded_files = st.file_uploader(
    "Upload one or more PDF or TXT files",
    type=["pdf", "txt"],
    accept_multiple_files=True,
)

if uploaded_files:
    st.write("Uploaded files:")
    for f in uploaded_files:
        st.write(f"- `{f.name}` ({f.size:,} bytes)")

current_signature = _signature(uploaded_files)
index_exists = st.session_state.store is not None
files_changed = (
    index_exists
    and current_signature != st.session_state.processed_signature
)
needs_processing = not index_exists or files_changed

if st.button(
    "Process documents",
    type="primary",
    disabled=not uploaded_files,
):
    if not uploaded_files:
        st.error("No documents uploaded. Please add at least one PDF or TXT file.")
    elif (
        current_signature == st.session_state.processed_signature
        and index_exists
    ):
        st.info("These documents are already processed.")
    else:
        with st.spinner("Extracting text, chunking, and building the index..."):
            store, ok_names, chunk_count, errors = _process_documents(uploaded_files)

        for message in errors:
            st.error(message)

        if store is None:
            st.error(
                "No documents could be processed. Fix the errors above "
                "and try again."
            )
        else:
            st.session_state.store = store
            st.session_state.processed_names = ok_names
            st.session_state.chunk_count = chunk_count
            st.session_state.processed_signature = current_signature
            st.session_state.last_result = None
            st.success(
                f"Processed {len(ok_names)} document(s) into "
                f"{chunk_count} chunks."
            )

if index_exists:
    col1, col2, col3 = st.columns(3)
    col1.metric("Documents", len(st.session_state.processed_names))
    col2.metric("Chunks indexed", st.session_state.chunk_count)
    col3.metric("Retrieved per question", TOP_K)
    with st.expander("Processed documents"):
        for name in st.session_state.processed_names:
            st.write(f"- `{name}`")
    if needs_processing and uploaded_files:
        st.warning(
            "The uploaded file set has changed. Click "
            "'Process documents' to rebuild the index before asking questions."
        )

st.divider()

# --------------------------------------------------------------------------
# 2. Question section
# --------------------------------------------------------------------------
st.header("2. Ask a question")

question = st.text_area(
    "Enter your question about the uploaded documents",
    height=100,
    placeholder="e.g. What is the main topic of the first document?",
)

ask_clicked = st.button("Get answer", type="primary")

if ask_clicked:
    if not question.strip():
        st.warning("Please enter a question before searching.")
    elif not index_exists:
        st.error(
            "No documents have been processed yet. "
            "Upload and process documents first."
        )
    elif files_changed:
        st.warning(
            "The uploaded file set has changed. "
            "Click 'Process documents' to rebuild the index first."
        )
    else:
        with st.spinner("Searching documents and generating an answer..."):
            try:
                result: QAResult = answer_question(
                    question.strip(), st.session_state.store
                )
                st.session_state.last_result = {
                    "question": question.strip(),
                    "result": result,
                }
            except QAError as exc:
                st.session_state.last_result = None
                st.error(str(exc))

st.divider()

# --------------------------------------------------------------------------
# 3. Answer section
# --------------------------------------------------------------------------
st.header("3. Answer")

last = st.session_state.last_result
if last is None:
    st.info("Ask a question to see the answer and its supporting context.")
else:
    result: QAResult = last["result"]
    st.markdown(f"**Question:** {last['question']}")

    if result.found:
        st.subheader("Generated answer")
        st.write(result.answer)
        score_text = (
            f" (best similarity: {result.best_score:.3f})"
            if result.best_score is not None
            else ""
        )
        st.caption(
            f"Grounded in {len(result.sources)} retrieved chunk(s){score_text}."
        )
    else:
        st.info(result.answer)
        if result.best_score is not None:
            st.caption(
                f"Best similarity score was {result.best_score:.3f}, "
                "below the configured threshold; the language model was "
                "not called."
            )

    st.subheader("Retrieved supporting context")
    if not result.sources:
        st.caption("No chunks were used for this response.")
    else:
        for i, src in enumerate(result.sources, start=1):
            label = (
                f"Source {i}: {src.document_name} | Chunk {src.chunk_id} | "
                f"Score {src.score:.3f}"
            )
            with st.expander(label):
                st.write(src.text)
