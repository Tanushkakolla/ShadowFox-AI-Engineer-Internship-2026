"""Central configuration for the document Q&A assistant."""

# --- Embeddings ---
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
EMBEDDING_DIM = 384

# --- Answer generation (Groq) ---
GROQ_MODEL = "qwen/qwen3.8-27b"

# --- Chunking ---
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200

# --- Retrieval ---
TOP_K = 4

# Similarity threshold (cosine, after L2 normalization => inner product score).
# This is a STARTING POINT only, not a universally correct value.
# It will be tested and tuned later against real documents.
SIMILARITY_THRESHOLD = 0.25

# --- Files ---
SUPPORTED_EXTENSIONS = {".pdf", ".txt"}
