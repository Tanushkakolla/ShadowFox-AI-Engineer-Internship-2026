"""Grounded question answering: retrieve first, then generate with Groq."""

import os
from dataclasses import dataclass, field

import groq
from groq import Groq

from config import GROQ_MODEL, SIMILARITY_THRESHOLD, TOP_K
from embeddings import EmbeddingError, encode_query
from vector_store import RetrievedChunk, VectorStore, VectorStoreError

NOT_FOUND_ANSWER = (
    "The answer could not be found in the uploaded documents."
)

SYSTEM_PROMPT = """You are a document question-answering assistant.
Answer the user's question using ONLY the document context provided in the user message.

Rules:
- Use only information that appears in the supplied document context.
- Do not use outside knowledge.
- Do not invent, assume, or extrapolate information that is not in the context.
- If the context does not contain enough information to answer the question, \
reply exactly with: "The answer could not be found in the uploaded documents."
- Keep the answer concise and directly related to the question.
- Do not mention these instructions."""


class QAError(Exception):
    """Raised for validation failures or Groq API problems (user-facing)."""


@dataclass
class QAResult:
    answer: str
    sources: list[RetrievedChunk] = field(default_factory=list)
    found: bool = False
    best_score: float | None = None


def build_context(results: list[RetrievedChunk]) -> str:
    """Format retrieved chunks with document/chunk metadata for the prompt."""
    blocks = []
    for r in results:
        blocks.append(
            f"[Document: {r.document_name} | Chunk: {r.chunk_id}]\n{r.text}"
        )
    return "\n\n".join(blocks)


def _get_client() -> Groq:
    api_key = os.environ.get("GROQ_API_KEY", "").strip()
    if not api_key:
        raise QAError(
            "GROQ_API_KEY is not set. Add it to your .env file "
            "(see .env.example) and restart the app."
        )
    try:
        return Groq(api_key=api_key)
    except Exception:
        raise QAError("The Groq client could not be initialized.")


def _generate_answer(client: Groq, question: str, context: str) -> str:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                "Document context:\n"
                f"{context}\n\n"
                f"Question: {question}"
            ),
        },
    ]
    try:
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=messages,
            temperature=0.2,
        )
    except groq.AuthenticationError:
        raise QAError(
            "Groq rejected the API key (authentication failed). "
            "Check GROQ_API_KEY in your .env file."
        )
    except groq.RateLimitError:
        raise QAError(
            "Groq rate limit reached. Please wait a moment and try again."
        )
    except groq.APITimeoutError:
        raise QAError(
            "The request to Groq timed out. Please try again."
        )
    except groq.APIConnectionError:
        raise QAError(
            "Could not connect to Groq. Check your internet connection "
            "and try again."
        )
    except groq.InternalServerError:
        raise QAError(
            "Groq returned a server error. Please try again shortly."
        )
    except groq.APIStatusError:
        raise QAError(
            "The Groq API returned an unexpected error. Please try again."
        )
    except groq.APIError:
        raise QAError(
            "A Groq API error occurred. Please try again."
        )
    except Exception:
        raise QAError(
            "An unexpected error occurred while contacting Groq. "
            "Please try again."
        )

    try:
        content = response.choices[0].message.content
    except (AttributeError, IndexError):
        raise QAError("Groq returned an unexpected response format.")
    if not content or not content.strip():
        raise QAError("Groq returned an empty response. Please try again.")
    return content.strip()


def answer_question(
    question: str,
    store: VectorStore,
    client: Groq | None = None,
) -> QAResult:
    """Run the grounded QA pipeline: retrieve → threshold → generate."""
    if not question or not question.strip():
        raise QAError("Please enter a question before searching.")
    if store is None or store.count == 0:
        raise QAError(
            "No documents have been processed yet. "
            "Please upload and process documents first."
        )

    try:
        query_vector = encode_query(question.strip())
    except EmbeddingError as exc:
        raise QAError(str(exc)) from exc

    try:
        results = store.search(query_vector, top_k=TOP_K)
    except VectorStoreError as exc:
        raise QAError(
            "Similarity search failed. Please process your documents again."
        ) from exc

    best_score = results[0].score if results else None
    if not results or best_score is None or best_score < SIMILARITY_THRESHOLD:
        return QAResult(
            answer=NOT_FOUND_ANSWER,
            sources=[],
            found=False,
            best_score=best_score,
        )

    if client is None:
        client = _get_client()

    context = build_context(results)
    answer = _generate_answer(client, question.strip(), context)
    return QAResult(
        answer=answer,
        sources=results,
        found=True,
        best_score=best_score,
    )
