"""Deterministic fixed-window character chunking with overlap."""

from dataclasses import dataclass

from config import CHUNK_OVERLAP, CHUNK_SIZE


@dataclass(frozen=True)
class Chunk:
    text: str
    document_name: str
    chunk_id: int


def chunk_text(
    text: str,
    document_name: str,
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
) -> list[Chunk]:
    """Split text into overlapping fixed-size character windows.

    Strategy: sliding window over characters.
      - step = chunk_size - chunk_overlap
      - chunk i covers [i * step, i * step + chunk_size)
      - consecutive chunks therefore share exactly `chunk_overlap` characters

    Deterministic and simple to explain: same input always yields the same
    chunks, and the overlap between neighbors is exactly the configured value.
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be greater than 0.")
    if chunk_overlap < 0 or chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be >= 0 and < chunk_size.")

    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    if not normalized.strip():
        return []

    step = chunk_size - chunk_overlap
    chunks: list[Chunk] = []
    start = 0
    chunk_id = 0

    while start < len(normalized):
        end = min(start + chunk_size, len(normalized))
        piece = normalized[start:end]
        if piece.strip():
            chunks.append(
                Chunk(text=piece, document_name=document_name, chunk_id=chunk_id)
            )
            chunk_id += 1
        if end >= len(normalized):
            break
        start += step

    return chunks
